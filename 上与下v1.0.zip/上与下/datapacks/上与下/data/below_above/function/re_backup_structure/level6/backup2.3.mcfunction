execute in below_above:backup2_structure run setblock 2 -27 2 minecraft:bedrock
execute in below_above:backup2_structure run setblock 2 -4 2 minecraft:air
execute in below_above:backup2_structure run forceload remove -16 -16 15 15