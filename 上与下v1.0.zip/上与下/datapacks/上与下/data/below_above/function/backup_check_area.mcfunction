execute if score level dummy matches 0 if entity @s[x=-80,y=-10,z=16,dx=14,dy=22,dz=14] run return run scoreboard players add #backup_check dummy 1
execute if score level dummy matches 1 if entity @s[x=-127,y=-13,z=52,dx=12,dy=18,dz=6] run return run scoreboard players add #backup_check dummy 1
execute if score level dummy matches 2 if entity @s[x=-144,y=-49,z=0,dx=15,dy=91,dz=15] run return run scoreboard players add #backup_check dummy 1
execute if score level dummy matches 3 if entity @s[x=-96,y=0,z=-80,dx=47,dy=96,dz=47] run return run scoreboard players add #backup_check dummy 1
execute if score level dummy matches 4 if entity @s[x=-24,y=-6,z=53,dx=16,dy=16,dz=21] run return run scoreboard players add #backup_check dummy 1
execute if score level dummy matches 5 if entity @s[x=-89,y=-9,z=87,dx=19,dy=10,dz=19] run return run scoreboard players add #backup_check dummy 1
execute if score level dummy matches 6 if entity @s[x=-12,y=-31,z=-12,dx=24,dy=95,dz=24] run return run scoreboard players add #backup_check dummy 1
tellraw @s {"text":"请在密室范围内尝试备份！","color":"red"}