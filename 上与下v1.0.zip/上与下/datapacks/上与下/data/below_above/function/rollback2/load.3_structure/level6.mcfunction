execute in minecraft:overworld run teleport @e[x=-12,y=-31,z=-12,dx=24,dy=96,dz=24,type=!minecraft:player] 0 -128 0
execute in minecraft:overworld run kill @e[x=0.5,y=-128,z=0.5,distance=..1]

execute in minecraft:overworld run setblock 2 -4 2 minecraft:redstone_block
execute in minecraft:overworld run setblock 2 -27 2 minecraft:redstone_block
execute in minecraft:overworld run setblock 2 -3 2 minecraft:bedrock
execute in minecraft:overworld run setblock 2 -8 2 minecraft:bedrock

schedule function below_above:rollback_entity_data/level6.1 2t append

execute if score #backup2_Health dummy < 2000000000 dummy run return \
  run function below_above:rollback2/load.4_health.1
#不满血，执行函数

schedule function below_above:rollback2/load.5_effects/give_hidden_effect.1 2t append
#满血，跳过一项