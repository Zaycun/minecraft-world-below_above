execute in minecraft:overworld run teleport @e[x=-127,y=-13,z=52,dx=12,dy=19,dz=6,type=!minecraft:player] -120 -128 55
execute in minecraft:overworld run kill @e[x=-120.5,y=-128,z=55.5,distance=..1]

execute in minecraft:overworld run setblock -115 -12 58 minecraft:redstone_block
execute in minecraft:overworld run setblock -115 4 58 minecraft:air

execute if score #backup2_Health dummy < 2000000000 dummy run return \
  run function below_above:rollback2/load.4_health.1
#不满血，执行函数

schedule function below_above:rollback2/load.5_effects/give_hidden_effect.1 2t append
#满血，跳过一项