data modify storage below_above:rollback2 advancements_husbandry_id set value none
$data modify storage below_above:rollback2 advancement_husbandry_id set from storage below_above:backup2_advancements husbandry[$(advancements_count)]
function below_above:rollback2/load.8_advancements/husbandry.3 with storage below_above:rollback2
#获取当前计数的进度id