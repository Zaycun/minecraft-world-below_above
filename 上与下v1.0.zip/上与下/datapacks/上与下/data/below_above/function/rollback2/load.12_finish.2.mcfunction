scoreboard players reset #present_Fire
attribute @s minecraft:block_interaction_range modifier remove below_above:remove_block_range
attribute @s entity_interaction_range modifier remove below_above:remove_entity_range
execute unless score level dummy matches 6 run gamerule natural_health_regeneration true
gamerule show_advancement_messages true
gamerule fall_damage true
gamerule drowning_damage true
gamerule fire_damage true
gamerule freeze_damage true
tellraw @s {text:"已回档至备份2",color:"#f2fb6f"}
scoreboard players set #is_loading dummy 0