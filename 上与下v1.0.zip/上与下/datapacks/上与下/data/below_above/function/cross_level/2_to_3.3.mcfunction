gamemode survival @s
execute in minecraft:overworld run teleport @s -73 82 -57 0 0
stopwatch restart below_above:level_time_taken
execute as @a at @s run playsound minecraft:entity.experience_orb.pickup ui @a ~ ~ ~ 1.0 1.0
playsound minecraft:entity.experience_orb.pickup ui @s -73 82 -57 1.0 1.0
scoreboard players set level dummy 3