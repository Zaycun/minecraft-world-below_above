execute if score level dummy matches 7 run return fail
scoreboard players set level dummy 7
scoreboard players set is_starting dummy 0

function below_above:backup_reset/create
#创建重置备份

clear @s
effect clear @s
effect give @s instant_health 1 252 true
effect give @s resistance 1 4 true
experience add @s -2147483647 points
spawnpoint @s 0 1 0 0 0
setworldspawn 0 1 0 0 0
time set 174000t
weather clear
worldborder center 0 0
worldborder set 59999968
gamerule natural_health_regeneration true

scoreboard players set #has_backup1 dummy 0
scoreboard players set #has_backup2 dummy 0
scoreboard players set #has_backup3 dummy 0

execute store result storage below_above:statistics level6_backup_times int 1 run scoreboard players get #level_backup_times dummy
execute store result storage below_above:statistics level6_rollback_times int 1 run scoreboard players get #level_rollback_times dummy

scoreboard players reset #level_backup_times dummy
scoreboard players reset #level_rollback_times dummy

execute store result score #level_time_taken dummy run stopwatch query below_above:level_time_taken 1000
scoreboard players operation #level_time_taken_h dummy = #level_time_taken dummy
scoreboard players operation #level_time_taken_ms dummy = #level_time_taken_h dummy
scoreboard players operation #level_time_taken_h dummy /= 3600000 dummy
scoreboard players operation #level_time_taken_ms dummy %= 3600000 dummy
scoreboard players operation #level_time_taken_m dummy = #level_time_taken_ms dummy
scoreboard players operation #level_time_taken_m dummy /= 60000 dummy
scoreboard players operation #level_time_taken_ms dummy %= 60000 dummy
scoreboard players operation #level_time_taken_s dummy = #level_time_taken_ms dummy
scoreboard players operation #level_time_taken_s dummy /= 1000 dummy
scoreboard players operation #level_time_taken_ms dummy %= 1000 dummy


execute store result storage below_above:statistics level6_time_taken_h int 1 run scoreboard players get #level_time_taken_h dummy
execute store result storage below_above:statistics level6_time_taken_m int 1 run scoreboard players get #level_time_taken_m dummy
execute store result storage below_above:statistics level6_time_taken_s int 1 run scoreboard players get #level_time_taken_s dummy
execute store result storage below_above:statistics level6_time_taken_ms int 1 run scoreboard players get #level_time_taken_ms dummy

execute if score #level_time_taken_ms dummy matches 0..9 run data modify storage below_above:statistics level6_time_taken_placeholder set value "00"
execute if score #level_time_taken_ms dummy matches 10..99 run data modify storage below_above:statistics level6_time_taken_placeholder set value "0"
execute if score #level_time_taken_ms dummy matches 100..999 run data modify storage below_above:statistics level6_time_taken_placeholder set value ""

#存储计时
tellraw @a \
  [\
    {\
      text:"过关！",color:"#b1f7f2",bold:true,\
    },\
    {\
      text:"关卡6用时：",color:"#e0e0e0",bold:false,\
    },\
    {\
      score:{name:"#level_time_taken_h",objective:dummy},color:"white",bold:false,extra:[{text:"h",color:"#cecaca"}]\
    },\
    {\
      score:{name:"#level_time_taken_m",objective:dummy},color:"white",bold:false,extra:[{text:"m",color:"#cecaca"}]\
    },\
    {\
      score:{name:"#level_time_taken_s",objective:dummy},color:"white",bold:false,extra:[{text:"s",color:"#cecaca"}]\
    }\
  ]
#本关用时

execute store result storage below_above:statistics total_backup_times int 1 run scoreboard players get #total_backup_times dummy
execute store result storage below_above:statistics total_rollback_times int 1 run scoreboard players get #total_rollback_times dummy
#总备份回档次数

execute store result score #total_time_taken dummy run stopwatch query below_above:total_time_taken 1000
scoreboard players operation #total_time_taken_h dummy = #total_time_taken dummy
scoreboard players operation #total_time_taken_ms dummy = #total_time_taken_h dummy
scoreboard players operation #total_time_taken_h dummy /= 3600000 dummy
scoreboard players operation #total_time_taken_ms dummy %= 3600000 dummy
scoreboard players operation #total_time_taken_m dummy = #total_time_taken_ms dummy
scoreboard players operation #total_time_taken_m dummy /= 60000 dummy
scoreboard players operation #total_time_taken_ms dummy %= 60000 dummy
scoreboard players operation #total_time_taken_s dummy = #total_time_taken_ms dummy
scoreboard players operation #total_time_taken_s dummy /= 1000 dummy
scoreboard players operation #total_time_taken_ms dummy %= 1000 dummy
execute store result storage below_above:statistics total_time_taken_h int 1 run scoreboard players get #total_time_taken_h dummy
execute store result storage below_above:statistics total_time_taken_m int 1 run scoreboard players get #total_time_taken_m dummy
execute store result storage below_above:statistics total_time_taken_s int 1 run scoreboard players get #total_time_taken_s dummy
execute store result storage below_above:statistics total_time_taken_ms int 1 run scoreboard players get #total_time_taken_ms dummy

execute if score #total_time_taken_ms dummy matches 0..9 run data modify storage below_above:statistics total_time_taken_placeholder set value "00"
execute if score #total_time_taken_ms dummy matches 10..99 run data modify storage below_above:statistics total_time_taken_placeholder set value "0"
execute if score #total_time_taken_ms dummy matches 100..999 run data modify storage below_above:statistics total_time_taken_placeholder set value ""
#总用时

title @s title {text:"通关！",color:"#b1f7f2"}
title @s subtitle \
  [\
    {\
      text:"总计用时：",color:"#e0e0e0",bold:false,\
    },\
    {\
      score:{name:"#total_time_taken_h",objective:dummy},color:"white",bold:false,extra:[{text:"h",color:"#cecaca"}]\
    },\
    {\
      score:{name:"#total_time_taken_m",objective:dummy},color:"white",bold:false,extra:[{text:"m",color:"#cecaca"}]\
    },\
    {\
      score:{name:"#total_time_taken_s",objective:dummy},color:"white",bold:false,extra:[{text:"s",color:"#cecaca"}]\
    }\
  ]

stopwatch remove below_above:level_time_taken
stopwatch remove below_above:total_time_taken

execute as @a at @s run playsound minecraft:entity.experience_orb.pickup ui @a ~ ~ ~ 1.0 1.259921
playsound minecraft:entity.experience_orb.pickup ui @s 0 1 0 1.0 1.259921