execute if score level dummy matches 3.. run return fail
scoreboard players set level dummy -1

function below_above:backup_reset/create
#创建重置备份

clear @s
effect clear @s
gamemode spectator @s
effect give @s instant_health 1 252 true
effect give @s resistance 1 4 true
experience add @s -2147483647 points
spawnpoint @s -73 82 -57 0 0
setworldspawn -73 82 -57 0 0
weather thunder
worldborder center -73 -57
worldborder set 81
time set 78000t

scoreboard players set #has_backup1 dummy 0
scoreboard players set #has_backup2 dummy 0
scoreboard players set #has_backup3 dummy 0


title @s title {text:"关卡3",color:"#b1f7f2"}
title @s subtitle {text:"星系"}


execute store result storage below_above:statistics level2_backup_times int 1 run scoreboard players get #level_backup_times dummy
execute store result storage below_above:statistics level2_rollback_times int 1 run scoreboard players get #level_rollback_times dummy

scoreboard players reset #level_backup_times dummy
scoreboard players reset #level_rollback_times dummy

execute store result score #level_time_taken dummy run stopwatch query below_above:level_time_taken 1000
scoreboard players operation #level_time_taken_h dummy = #level_time_taken dummy
scoreboard players operation #level_time_taken_ms dummy = #level_time_taken_h dummy
scoreboard players operation #level_time_taken_h dummy /= 3600000 dummy
scoreboard players operation #level_time_taken_ms dummy %= 3600000 dummy
scoreboard players operation #level_time_taken_m dummy = #level_time_taken_ms dummy
scoreboard players operation #level_time_taken_m dummy /= 60000 dummy
scoreboard players operation #level_time_taken_ms dummy %= 60000 dummy
scoreboard players operation #level_time_taken_s dummy = #level_time_taken_ms dummy
scoreboard players operation #level_time_taken_s dummy /= 1000 dummy
scoreboard players operation #level_time_taken_ms dummy %= 1000 dummy


execute store result storage below_above:statistics level2_time_taken_h int 1 run scoreboard players get #level_time_taken_h dummy
execute store result storage below_above:statistics level2_time_taken_m int 1 run scoreboard players get #level_time_taken_m dummy
execute store result storage below_above:statistics level2_time_taken_s int 1 run scoreboard players get #level_time_taken_s dummy
execute store result storage below_above:statistics level2_time_taken_ms int 1 run scoreboard players get #level_time_taken_ms dummy

execute if score #level_time_taken_ms dummy matches 0..9 run data modify storage below_above:statistics level2_time_taken_placeholder set value "00"
execute if score #level_time_taken_ms dummy matches 10..99 run data modify storage below_above:statistics level2_time_taken_placeholder set value "0"
execute if score #level_time_taken_ms dummy matches 100..999 run data modify storage below_above:statistics level2_time_taken_placeholder set value ""


#存储计时
tellraw @a \
  [\
    {\
      text:"过关！",color:"#b1f7f2",bold:true,\
    },\
    {\
      text:"关卡2用时：",color:"#e0e0e0",bold:false,\
    },\
    {\
      score:{name:"#level_time_taken_h",objective:dummy},color:"white",bold:false,extra:[{text:"h",color:"#cecaca"}]\
    },\
    {\
      score:{name:"#level_time_taken_m",objective:dummy},color:"white",bold:false,extra:[{text:"m",color:"#cecaca"}]\
    },\
    {\
      score:{name:"#level_time_taken_s",objective:dummy},color:"white",bold:false,extra:[{text:"s",color:"#cecaca"}]\
    }\
  ]


schedule function below_above:cross_level/2_to_3.2 2t append