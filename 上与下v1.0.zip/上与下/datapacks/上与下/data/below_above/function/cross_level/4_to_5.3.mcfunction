gamemode survival @s
execute in minecraft:overworld run teleport @s -86 -6 90 0 0
stopwatch restart below_above:level_time_taken
execute as @a at @s run playsound minecraft:entity.experience_orb.pickup ui @a ~ ~ ~ 1.0 1.122462
playsound minecraft:entity.experience_orb.pickup ui @s -86 -6 90 1.0 1.122462
scoreboard players set level dummy 5