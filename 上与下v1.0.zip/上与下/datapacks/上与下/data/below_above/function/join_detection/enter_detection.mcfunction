execute as @a at @s if score @s enter_detection matches 1.. run function below_above:join_detection/enter
