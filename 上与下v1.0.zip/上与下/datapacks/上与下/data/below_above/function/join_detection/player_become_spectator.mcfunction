
clear @s

advancement revoke @s everything

tag @s remove player
recipe take @a *
effect clear @s
effect give @s night_vision infinite 255 true
experience add @s -2147483647 points
attribute @s minecraft:waypoint_receive_range base reset
spawnpoint @s -73 1 23 180 0
gamemode spectator @s

tellraw @s {text:"一名玩家正在游戏中，你已加入旁观者。",color:"red"}