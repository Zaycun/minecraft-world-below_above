execute in minecraft:overworld run teleport @e[x=-24,y=-6,z=53,dx=16,dy=17,dz=21,type=!minecraft:player] -10 -128 72
execute in minecraft:overworld run kill @e[x=-9.5,y=-128,z=72.5,distance=..1]

execute in minecraft:overworld run setblock -24 -5 73 minecraft:redstone_block
execute in minecraft:overworld run setblock -24 4 73 minecraft:air

execute if score #backup1_Health dummy < 2000000000 dummy run return \
  run function below_above:rollback1/load.4_health.1
#不满血，执行函数

schedule function below_above:rollback1/load.5_effects/give_hidden_effect.1 2t append
#满血，跳过一项