execute in minecraft:overworld run teleport @e[x=-96,y=0,z=-80,dx=47,dy=97,dz=47,type=!minecraft:player] -73 -128 -57
execute in minecraft:overworld run kill @e[x=-72.5,y=-128,z=-56.5,distance=..1]

execute in minecraft:overworld run setblock -91 1 -39 minecraft:redstone_block
execute in minecraft:overworld run setblock -91 49 -39 minecraft:redstone_block
execute in minecraft:overworld run setblock -91 45 -39 minecraft:bedrock
execute in minecraft:overworld run setblock -91 95 -39 minecraft:bedrock

schedule function below_above:rollback_entity_data/level3.1 2t append

execute if score #backup1_Health dummy < 2000000000 dummy run return \
  run function below_above:rollback1/load.4_health.1
#不满血，执行函数

schedule function below_above:rollback1/load.5_effects/give_hidden_effect.1 2t append
#满血，跳过一项