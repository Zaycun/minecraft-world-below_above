execute in minecraft:overworld run teleport @e[x=-80,y=-10,z=16,dx=14,dy=23,dz=14,type=!player] -73 -128 23
execute in minecraft:overworld run kill @e[x=-72.5,y=-128,z=23.5,distance=..1]

execute in minecraft:overworld run setblock -80 -9 30 minecraft:redstone_block
execute in minecraft:overworld run setblock -80 11 30 minecraft:air

execute if score #backup1_Health dummy < 2000000000 dummy run return \
  run function below_above:rollback1/load.4_health.1
#不满血，执行函数

schedule function below_above:rollback1/load.5_effects/give_hidden_effect.1 2t append
#满血，跳过一项