execute in minecraft:overworld run setblock -8 9 74 minecraft:air

execute in below_above:backup2_structure run teleport @e[x=-24,y=-6,z=53,dx=16,dy=17,dz=21,type=!minecraft:player] -10 -128 72
execute in below_above:backup2_structure run kill @e[x=-9.5,y=-128,z=72.5,distance=..1]
execute in below_above:backup2_structure run setblock -8 -5 74 minecraft:redstone_block
execute in below_above:backup2_structure run setblock -8 9 74 minecraft:air
execute in below_above:backup2_structure run forceload remove -32 48 -1 79

schedule function below_above:backup2/finish.1 5t