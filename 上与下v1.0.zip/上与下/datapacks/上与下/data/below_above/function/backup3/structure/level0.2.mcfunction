execute in minecraft:overworld run setblock -66 11 16 minecraft:air

execute in below_above:backup3_structure run teleport @e[x=-80,y=-10,z=16,dx=14,dy=23,dz=14,type=!minecraft:player] -73 -128 23
execute in below_above:backup3_structure run kill @e[x=-72.5,y=-128,z=23.5,distance=..1]
execute in below_above:backup3_structure run setblock -66 -9 16 minecraft:redstone_block
execute in below_above:backup3_structure run setblock -66 11 16 minecraft:air
execute in below_above:backup3_structure run forceload remove -80 16 -65 31

schedule function below_above:backup3/finish.1 5t