scoreboard players reset @s config.trigger

function below_above:backup_check
execute if score #backup_check dummy matches 10 run function below_above:backup1/create
scoreboard players reset #backup_check dummy
