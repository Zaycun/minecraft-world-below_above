execute in minecraft:overworld run setblock -2 -8 2 minecraft:bedrock
execute in minecraft:overworld run setblock -2 -3 2 minecraft:bedrock

execute in below_above:backup1_structure run teleport @e[x=-12,y=-31,z=-12,dx=24,dy=96,dz=24,type=!minecraft:player] 0 -128 0
execute in below_above:backup1_structure run kill @e[x=0.5,y=-128,z=0.5,distance=..1]
execute in below_above:backup1_structure run setblock -2 -4 2 minecraft:redstone_block
execute in below_above:backup1_structure run setblock -2 -27 2 minecraft:redstone_block
execute in below_above:backup1_structure run setblock -2 -8 2 minecraft:bedrock
execute in below_above:backup1_structure run setblock -2 -3 2 minecraft:bedrock
execute in below_above:backup1_structure run forceload remove -16 -16 15 15

schedule function below_above:backup1/finish.1 5t