data modify entity @s data.uuid_0 set from entity @s UUID[0]
data modify entity @s data.uuid_1 set from entity @s UUID[1]
data modify entity @s data.uuid_2 set from entity @s UUID[2]
data modify entity @s data.uuid_3 set from entity @s UUID[3]