execute if items entity @a[tag=!player,gamemode=!spectator] container.* * run return run tellraw @a {"text":"请清空旁观者身上的物品后再尝试备份！","color":"red"}
scoreboard players add #backup_check dummy 1