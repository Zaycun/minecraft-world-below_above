data modify storage below_above:global Version set value "1.1"

setworldspawn -73 1 23 180 0
scoreboard objectives add respawn_detection custom:time_since_death "重生检测"
scoreboard objectives add enter_detection minecraft.custom:minecraft.leave_game "上线检测"
scoreboard objectives add dummy dummy "虚拟型"
scoreboard objectives add config.trigger trigger "配置"
scoreboard objectives add entity_data_detection_uuid0 dummy "UUID_0检测"
scoreboard objectives add entity_data_detection_uuid1 dummy "UUID_1检测"
scoreboard objectives add entity_data_detection_uuid2 dummy "UUID_2检测"
scoreboard objectives add entity_data_detection_uuid3 dummy "UUID_3检测"

scoreboard players set level dummy -1
scoreboard players add #setting_night_vision dummy 0
scoreboard players add #setting_faster_mining dummy 0
scoreboard players add is_starting dummy 0

scoreboard players set 20 dummy 20
scoreboard players set 1000 dummy 1000
scoreboard players set 60000 dummy 60000
scoreboard players set 3600000 dummy 3600000
scoreboard players set 2000000000 dummy 2000000000

difficulty normal
gamerule minecraft:respawn_radius 0
gamerule minecraft:random_tick_speed 0
gamerule minecraft:advance_time false
gamerule minecraft:advance_weather false
gamerule minecraft:spawn_mobs false
gamerule minecraft:players_sleeping_percentage 0
gamerule minecraft:command_block_output false
gamerule minecraft:send_command_feedback false
gamerule minecraft:pvp false