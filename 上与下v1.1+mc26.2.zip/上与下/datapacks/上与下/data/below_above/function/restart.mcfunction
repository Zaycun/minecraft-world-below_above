tag @a remove player
scoreboard players set level dummy -1
scoreboard players set is_starting dummy 0
scoreboard players reset #total_backup_times dummy
scoreboard players reset #total_rollback_times dummy
scoreboard players reset #level_backup_times dummy
scoreboard players reset #level_rollback_times dummy 

scoreboard players set #setting_night_vision dummy 1
scoreboard players set #setting_faster_mining dummy 1


clear @a
advancement revoke @a everything
recipe take @a *
execute as @a run attribute @s minecraft:waypoint_receive_range base reset
effect clear @a
effect give @a saturation infinite 255 true
effect give @a weakness infinite 255 true
experience add @a -2147483647 points
execute as @a run attribute @s minecraft:block_break_speed base reset
execute as @a run attribute @s minecraft:block_interaction_range modifier remove below_above:remove_block_range
execute as @a run attribute @s entity_interaction_range modifier remove below_above:remove_entity_range

gamerule natural_health_regeneration true

spawnpoint @a -73 1 23 180 0
setworldspawn -73 1 23 180 0

weather clear
time set 0t
worldborder center 0 0
worldborder set 59999968

data remove storage below_above:backup_reset_advancements adventure
data remove storage below_above:backup_reset_advancements end
data remove storage below_above:backup_reset_advancements husbandry
data remove storage below_above:backup_reset_advancements nether
data remove storage below_above:backup_reset_advancements story
data remove storage below_above:backup_reset recipeBook
data remove storage below_above:present_advancements adventure
data remove storage below_above:present_advancements end
data remove storage below_above:present_advancements husbandry
data remove storage below_above:present_advancements nether
data remove storage below_above:present_advancements story

data remove storage below_above:statistics total_backup_times
data remove storage below_above:statistics total_rollback_times
data remove storage below_above:statistics total_time_taken_h
data remove storage below_above:statistics total_time_taken_m
data remove storage below_above:statistics total_time_taken_s
data remove storage below_above:statistics total_time_taken_ms

stopwatch remove below_above:total_time_taken
stopwatch remove below_above:level_time_taken

function below_above:rollback_reset/reset.2_structure/level0
function below_above:rollback_reset/reset.2_structure/level1
function below_above:rollback_reset/reset.2_structure/level2
function below_above:rollback_reset/reset.2_structure/level3
function below_above:rollback_reset/reset.2_structure/level4
function below_above:rollback_reset/reset.2_structure/level5
function below_above:rollback_reset/reset.2_structure/level6

data modify block -67 2 17 front_text.messages set value ["",{text:"点击此处",color:"#e5d257",bold:1b,click_event:{command:"function below_above:start",action:"run_command"}},{text:"开始游戏",color:"#e5d257",bold:1b,click_event:{command:"setblock -74 305 17 minecraft:redstone_block",action:"run_command"}},""]

tag @a remove opened_menu
gamemode adventure @a
teleport @a -73 1 23 180 0