data modify storage below_above:backup2 advancements_story_id set value none
$data modify storage below_above:backup2 advancements_story_id set from storage below_above:present_advancements story[$(advancements_count)]
function below_above:backup2/advancements/story.3 with storage below_above:backup2
#获取当前计数现在进度id