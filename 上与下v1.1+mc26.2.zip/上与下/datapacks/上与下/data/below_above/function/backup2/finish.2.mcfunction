scoreboard players set #is_loading dummy 0
$tellraw @s [{text:"[$(clock_hour):$(clock_minute):$(clock_second)]",color:"#f2fb6f"},{text:" 备份2创建完成！",color:"#ec93dc"}]