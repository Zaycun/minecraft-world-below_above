execute in minecraft:overworld run setblock -71 0 105 minecraft:redstone_block
execute in below_above:backup2_structure run forceload add -96 80 -65 111

schedule function below_above:backup2/structure/level5.2 4t append
#必须是4t