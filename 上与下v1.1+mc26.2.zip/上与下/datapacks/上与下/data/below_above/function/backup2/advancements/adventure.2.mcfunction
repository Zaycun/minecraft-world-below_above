data modify storage below_above:backup2 advancements_adventure_id set value none
$data modify storage below_above:backup2 advancements_adventure_id set from storage below_above:present_advancements adventure[$(advancements_count)]
function below_above:backup2/advancements/adventure.3 with storage below_above:backup2
#获取当前计数现在进度id