execute in minecraft:overworld run setblock -8 9 74 minecraft:redstone_block
execute in below_above:backup2_structure run forceload add -32 48 -1 79

schedule function below_above:backup2/structure/level4.2 4t append
#必须是4t