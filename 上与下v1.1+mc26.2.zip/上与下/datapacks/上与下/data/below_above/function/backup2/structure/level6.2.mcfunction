execute in minecraft:overworld run setblock 2 -8 2 minecraft:bedrock
execute in minecraft:overworld run setblock 2 -3 2 minecraft:bedrock

execute in below_above:backup2_structure run teleport @e[x=-12,y=-31,z=-12,dx=24,dy=96,dz=24,type=!minecraft:player] 0 -128 0
execute in below_above:backup2_structure run kill @e[x=0.5,y=-128,z=0.5,distance=..1]
execute in below_above:backup2_structure run place template below_above:backup2_above_and_below.2 -12 17 -12 none none 1 0 strict
execute in below_above:backup2_structure run place template below_above:backup2_above_and_below.1 -12 -31 -12 none none 1 0 strict
execute in below_above:backup2_structure run setblock 2 -8 2 minecraft:bedrock
execute in below_above:backup2_structure run setblock 2 -3 2 minecraft:bedrock
execute in below_above:backup2_structure run forceload remove -16 -16 15 15

schedule function below_above:backup2/finish.1 5t