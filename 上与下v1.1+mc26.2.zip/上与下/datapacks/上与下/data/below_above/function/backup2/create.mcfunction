scoreboard players set #is_loading dummy 1
scoreboard players set #has_backup2 dummy 1
scoreboard players add #level_backup_times dummy 1
scoreboard players add #total_backup_times dummy 1

data modify storage below_above:backup2 clock_hour set string block -75 305 17 LastOutput.text 1 3
data modify storage below_above:backup2 clock_minute set string block -75 305 17 LastOutput.text 4 6
data modify storage below_above:backup2 clock_second set string block -75 305 17 LastOutput.text 7 9

function below_above:backup2/player
function below_above:backup2/container
function below_above:backup2/advancements/adventure.1
function below_above:backup2/advancements/end.1
function below_above:backup2/advancements/husbandry.1
function below_above:backup2/advancements/nether.1
function below_above:backup2/advancements/story.1

execute if score level dummy matches 0 run function below_above:backup2/structure/level0.1
execute if score level dummy matches 1 run function below_above:backup2/structure/level1.1
execute if score level dummy matches 2 run function below_above:backup2/structure/level2.1
execute if score level dummy matches 3 run function below_above:backup2/structure/level3.1
execute if score level dummy matches 4 run function below_above:backup2/structure/level4.1
execute if score level dummy matches 5 run function below_above:backup2/structure/level5.1
execute if score level dummy matches 6 run function below_above:backup2/structure/level6.1
