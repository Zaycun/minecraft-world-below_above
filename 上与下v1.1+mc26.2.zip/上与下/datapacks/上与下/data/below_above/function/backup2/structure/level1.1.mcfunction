execute in minecraft:overworld run setblock -115 4 58 minecraft:redstone_block
execute in below_above:backup2_structure run forceload add -128 48 -113 63

schedule function below_above:backup2/structure/level1.2 4t append
#必须是4t