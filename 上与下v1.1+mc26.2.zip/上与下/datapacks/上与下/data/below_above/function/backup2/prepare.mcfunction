scoreboard players reset @s config.trigger

function below_above:backup_check
execute if score #backup_check dummy matches 11 run function below_above:backup2/create
scoreboard players reset #backup_check dummy
