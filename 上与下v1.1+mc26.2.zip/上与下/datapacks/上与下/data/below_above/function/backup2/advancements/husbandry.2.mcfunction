data modify storage below_above:backup2 advancements_husbandry_id set value none
$data modify storage below_above:backup2 advancements_husbandry_id set from storage below_above:present_advancements husbandry[$(advancements_count)]
function below_above:backup2/advancements/husbandry.3 with storage below_above:backup2
#获取当前计数现在进度id