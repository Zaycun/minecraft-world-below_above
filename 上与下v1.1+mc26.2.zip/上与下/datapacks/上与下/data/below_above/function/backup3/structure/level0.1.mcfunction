execute in minecraft:overworld run setblock -66 11 16 minecraft:redstone_block
execute in below_above:backup3_structure run forceload add -80 16 -65 31

schedule function below_above:backup3/structure/level0.2 4t append
#必须是4t