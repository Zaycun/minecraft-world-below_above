scoreboard players set #is_loading dummy 0
$tellraw @s [{text:"[$(clock_hour):$(clock_minute):$(clock_second)]",color:"#6fb3fb"},{text:" 备份3创建完成！",color:"#ec93dc"}]