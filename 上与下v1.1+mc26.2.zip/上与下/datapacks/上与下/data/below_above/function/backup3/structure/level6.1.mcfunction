execute as @e[x=-12,y=-31,z=-12,dx=24,dy=96,dz=24,type=!minecraft:player] run function below_above:backup_entity_data

execute in minecraft:overworld run setblock 2 -8 -2 minecraft:redstone_block
execute in minecraft:overworld run setblock 2 -3 -2 minecraft:redstone_block
execute in below_above:backup3_structure run forceload add -16 -16 15 15

schedule function below_above:backup3/structure/level6.2 4t append
#必须是4t