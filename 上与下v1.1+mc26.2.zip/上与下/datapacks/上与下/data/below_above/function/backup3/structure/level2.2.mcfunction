execute in minecraft:overworld run setblock -130 -6 0 minecraft:bedrock
execute in minecraft:overworld run setblock -130 41 0 minecraft:air

execute in below_above:backup3_structure run teleport @e[x=-144,y=-49,z=0,dx=15,dy=92,dz=15,type=!minecraft:player] -137 -128 7
execute in below_above:backup3_structure run kill @e[x=-136.5,y=-128,z=7.5,distance=..1]
execute in below_above:backup3_structure run place template below_above:backup3_mob_lab.1 -144 -49 0 none none 1 0 strict
execute in below_above:backup3_structure run place template below_above:backup3_mob_lab.2 -144 -3 0 none none 1 0 strict
execute in below_above:backup3_structure run setblock -130 -6 0 minecraft:bedrock
execute in below_above:backup3_structure run setblock -130 41 0 minecraft:air
execute in below_above:backup3_structure run forceload remove -144 0 -129 15

schedule function below_above:backup3/finish.1 5t