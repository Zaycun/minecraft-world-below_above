data modify storage below_above:backup3 advancements_husbandry_id set value none
$data modify storage below_above:backup3 advancements_husbandry_id set from storage below_above:present_advancements husbandry[$(advancements_count)]
function below_above:backup3/advancements/husbandry.3 with storage below_above:backup3
#获取当前计数现在进度id