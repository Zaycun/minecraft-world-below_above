$data modify storage below_above:backup3_advancements nether append value "$(advancements_nether_id)"

execute if score #backup_advancements_count dummy >= #backup_advancements_number dummy run return fail

scoreboard players add #backup_advancements_count dummy 1
execute store result storage below_above:backup3 advancements_count int 1 run scoreboard players get #backup_advancements_count dummy

function below_above:backup3/advancements/nether.2 with storage below_above:backup3