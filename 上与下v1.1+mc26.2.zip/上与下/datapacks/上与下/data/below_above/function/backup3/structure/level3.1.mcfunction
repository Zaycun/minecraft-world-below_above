execute as @e[x=-96,y=0,z=-80,dx=47,dy=97,dz=47,type=!minecraft:player] run function below_above:backup_entity_data

execute in minecraft:overworld run setblock -55 45 -75 minecraft:redstone_block
execute in minecraft:overworld run setblock -55 95 -75 minecraft:redstone_block
execute in below_above:backup3_structure run forceload add -96 -80 -49 -33

schedule function below_above:backup3/structure/level3.2 4t append
#必须是4t