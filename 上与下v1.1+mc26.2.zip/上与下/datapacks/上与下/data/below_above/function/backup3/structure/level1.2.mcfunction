execute in minecraft:overworld run setblock -115 4 52 minecraft:air

execute in below_above:backup3_structure run teleport @e[x=-127,y=-13,z=52,dx=12,dy=19,dz=6,type=!minecraft:player] -121 -128 55
execute in below_above:backup3_structure run kill @e[x=-120.5,y=-128,z=55.5,distance=..1]
execute in below_above:backup3_structure run place template below_above:backup3_mine_craft -127 -13 52 none none 1 0 strict
execute in below_above:backup3_structure run setblock -115 4 52 minecraft:air
execute in below_above:backup3_structure run forceload remove -128 48 -113 63

schedule function below_above:backup3/finish.1 5t