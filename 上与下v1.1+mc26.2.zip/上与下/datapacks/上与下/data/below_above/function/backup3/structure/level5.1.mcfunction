execute in minecraft:overworld run setblock -71 0 87 minecraft:redstone_block
execute in below_above:backup3_structure run forceload add -96 80 -65 111

schedule function below_above:backup3/structure/level5.2 4t append
#必须是4t