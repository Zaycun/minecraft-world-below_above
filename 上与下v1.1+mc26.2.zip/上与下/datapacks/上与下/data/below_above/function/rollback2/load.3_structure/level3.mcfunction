execute in minecraft:overworld run teleport @e[x=-96,y=0,z=-80,dx=47,dy=97,dz=47,type=!minecraft:player] -73 -128 -57
execute in minecraft:overworld run kill @e[x=-72.5,y=-128,z=-56.5,distance=..1]

execute in minecraft:overworld run place template below_above:backup2_galaxy.1 -96 0 -80 none none 1 0 strict
execute in minecraft:overworld run place template below_above:backup2_galaxy.2 -96 48 -80 none none 1 0 strict
execute in minecraft:overworld run setblock -55 45 -39 minecraft:air
execute in minecraft:overworld run setblock -55 95 -39 minecraft:air

schedule function below_above:rollback_entity_data/level3.1 2t append

execute if score #backup2_Health dummy < 2000000000 dummy run return \
  run function below_above:rollback2/load.4_health.1
#不满血，执行函数

schedule function below_above:rollback2/load.5_effects/give_hidden_effect.1 2t append
#满血，跳过一项