item replace entity @s armor.head with air

function below_above:rollback2/load.7_recipes/give_recipe.2