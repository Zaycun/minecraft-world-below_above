execute in minecraft:overworld run teleport @e[x=-80,y=-11,z=16,dx=14,dy=24,dz=14,type=!player] -73 -128 23
execute in minecraft:overworld run kill @e[x=-72.5,y=-128,z=23.5,distance=..1]

execute in minecraft:overworld run place template below_above:backup2_starting_room -80 -11 16 none none 1 0 strict
execute in minecraft:overworld run setblock -66 11 30 minecraft:air

execute if score #backup2_Health dummy < 2000000000 dummy run return \
  run function below_above:rollback2/load.4_health.1
#不满血，执行函数

schedule function below_above:rollback2/load.5_effects/give_hidden_effect.1 2t append
#满血，跳过一项