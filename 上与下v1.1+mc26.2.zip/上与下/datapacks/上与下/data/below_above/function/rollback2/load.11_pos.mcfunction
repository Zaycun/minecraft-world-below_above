$execute in $(dimension) run teleport @a[gamemode=!spectator,gamemode=!creative] $(pos_x) $(pos_y) $(pos_z) $(rot_y) $(rot_x)
$execute in $(respawn_dimension) run spawnpoint @a[gamemode=!spectator,gamemode=!creative] $(respawn_pos_x) $(respawn_pos_y) $(respawn_pos_z) $(respawn_rot_y) $(respawn_rot_x)


schedule function below_above:rollback2/load.12_finish.1 3t append