$item replace entity @a[tag=player,limit=1] armor.head with minecraft:knowledge_book\
  [enchantments={"below_above:get_fire2":$(fire),binding_curse:1},!item_name,!lore,tooltip_display={hide_tooltip:true},item_model="minecraft:air"] 1
schedule function below_above:rollback2/load.6_getfire/getfire.3 2t append