$execute in $(dimension) run teleport @s $(pos_x) $(pos_y) $(pos_z) $(rot_y) $(rot_x)
$execute in $(respawn_dimension) run spawnpoint @s $(respawn_pos_x) $(respawn_pos_y) $(respawn_pos_z) $(respawn_rot_y) $(respawn_rot_x)

execute at @a[tag=player] run fill ~0.3 ~0.0 ~0.3 ~-0.3 ~0.99 ~-0.3 minecraft:air
execute at @a[tag=player] run fill ~0.3 ~1.0 ~0.3 ~-0.3 ~1.8 ~-0.3 minecraft:oak_slab[type=top]

schedule function below_above:rollback2/load.3_structure/allocation 2t