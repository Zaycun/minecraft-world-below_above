gamemode survival @s
execute store result score #rollback_recipes_number dummy run data get storage below_above:backup2 recipeBook

execute if score #rollback_recipes_number dummy matches 0 run return run function below_above:rollback2/load.8_advancements
#无配方，跳转下一步

scoreboard players remove #rollback_recipes_number dummy 1
data modify storage below_above:rollback2 recipes_count set value 0
scoreboard players set #rollback_recipes_count dummy 0
function below_above:rollback2/load.7_recipes/give_recipe.3 with storage below_above:rollback2