data modify storage below_above:rollback2 advancements_adventure_id set value none
$data modify storage below_above:rollback2 advancement_adventure_id set from storage below_above:backup2_advancements adventure[$(advancements_count)]
function below_above:rollback2/load.8_advancements/adventure.3 with storage below_above:rollback2
#获取当前计数的进度id