execute if score #backup2_Health dummy >= 2000000000 dummy run return \
  run function below_above:rollback2/load.5_effects/give_absorption.2
schedule function below_above:rollback2/load.5_effects/give_absorption.2 2t append