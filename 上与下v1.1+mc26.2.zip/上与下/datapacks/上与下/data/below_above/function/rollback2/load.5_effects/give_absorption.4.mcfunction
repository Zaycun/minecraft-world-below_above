$effect give @s minecraft:absorption $(effect_seconds) $(effect_amplifier) false

execute if score #backup2_Health dummy >= 2000000000 dummy \
  run return run function below_above:rollback2/load.5_effects/give_absorption.5
schedule function below_above:rollback2/load.5_effects/give_absorption.5 7t append

