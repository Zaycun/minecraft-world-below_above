$effect give @s $(hidden_effect_id) $(hidden_effect_seconds) $(hidden_effect_amplifier)
function below_above:rollback2/load.5_effects/give_hidden_effect.6 with storage below_above:rollback2