data remove storage below_above:rollback2 effect_id
data remove storage below_above:rollback2 effect_seconds
data remove storage below_above:rollback2 effect_amplifier


execute if score #present_Fire dummy matches ..0 if score #backup2_Fire dummy matches 1.. run return run function below_above:rollback2/load.6_getfire/branch.1
#不在着火，但备份着火，执行下一项

execute if score #present_Fire dummy matches ..0 if score #backup2_Fire dummy matches ..0 run return run function below_above:rollback2/load.7_recipes/give_recipe.1
#不在着火，备份也不着火，跳过下一项


gamemode creative @s

execute if score #backup2_Fire dummy matches ..0 run return run schedule function below_above:rollback2/load.7_recipes/give_recipe.1 2t append
#在着火，备份不着火，跳过下一项

execute if score #backup2_Fire dummy matches 1.. run return run schedule function below_above:rollback2/load.6_getfire/branch.1 2t append
#在着火，备份着火，执行下一项