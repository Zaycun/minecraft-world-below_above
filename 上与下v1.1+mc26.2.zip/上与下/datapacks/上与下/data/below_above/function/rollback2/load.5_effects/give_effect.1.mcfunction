data remove storage below_above:rollback2 hidden_effect_id
data remove storage below_above:rollback2 hidden_effect_seconds
data remove storage below_above:rollback2 hidden_effect_amplifier

scoreboard players set #rollback_effects_count dummy 0
data modify storage below_above:rollback2 effects_count set value 0
function below_above:rollback2/load.5_effects/give_effect.2 with storage below_above:rollback2