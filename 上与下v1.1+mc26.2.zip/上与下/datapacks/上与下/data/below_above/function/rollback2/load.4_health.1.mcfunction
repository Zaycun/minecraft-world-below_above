scoreboard players operation #rollback2_damage.1 dummy = 2000000000 dummy
execute store result storage below_above:rollback2 damage1 float 0.00000001 \
  run scoreboard players operation #rollback2_damage.1 dummy -= #backup2_Health dummy

scoreboard players reset #rollback2_damage.1 dummy
schedule function below_above:rollback2/load.4_health.2 2t append