$effect give @s $(effect_id) $(effect_seconds) $(effect_amplifier)

execute if score #rollback_effects_count dummy >= #rollback_effects_number dummy run return \
  run function below_above:rollback2/load.5_effects/give_effect.4

scoreboard players add #rollback_effects_count dummy 1
execute store result storage below_above:rollback2 effects_count int 1 \
  run scoreboard players get #rollback_effects_count dummy
function below_above:rollback2/load.5_effects/give_effect.2 with storage below_above:rollback2