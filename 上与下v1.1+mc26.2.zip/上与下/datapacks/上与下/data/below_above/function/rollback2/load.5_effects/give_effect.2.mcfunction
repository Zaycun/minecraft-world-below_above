data modify storage below_above:rollback2 effect_seconds set value 1
$execute store result score #rollback_effect_seconds dummy \
  run data get storage below_above:backup2 active_effects[$(effects_count)].duration
execute if score #rollback_effect_seconds dummy matches -1 run data modify storage below_above:rollback2 effect_seconds set value "infinite"
execute if score #rollback_effect_seconds dummy matches 1.. store result storage below_above:rollback2 effect_seconds int 1 \
  run scoreboard players operation #rollback_effect_seconds dummy /= 20 dummy
#效果时长存入命令存储

data modify storage below_above:rollback2 effect_id set value "none"
$data modify storage below_above:rollback2 effect_id set from storage below_above:backup2 active_effects[$(effects_count)].id
#将效果id存入命令存储

data modify storage below_above:rollback2 effect_amplifier set value 0
$execute store result score #rollback_effect_amplifier dummy run data get storage below_above:backup2 active_effects[$(effects_count)].amplifier
execute if score #rollback_effect_amplifier dummy matches ..-1 run scoreboard players set #rollback_effect_amplifier dummy 255
execute store result storage below_above:rollback2 effect_amplifier int 1 run scoreboard players get #rollback_effect_amplifier dummy
#效果等级存入命令存储

execute if data storage below_above:rollback2 {effect_id: "minecraft:absorption"} run return \
  run function below_above:rollback2/load.5_effects/give_absorption.1
#如果是伤害吸收，则中断函数，执行

scoreboard players set #is_show_particles dummy 1
$execute if data storage below_above:backup2 active_effects[$(effects_count)].show_particles store result score #is_show_particles dummy run data get storage below_above:backup2 active_effects[$(effects_count)].show_particles
execute if score #is_show_particles dummy matches 0 run return \
  run function below_above:rollback2/load.5_effects/give_effect.3_true with storage below_above:rollback2
function below_above:rollback2/load.5_effects/give_effect.3_false with storage below_above:rollback2