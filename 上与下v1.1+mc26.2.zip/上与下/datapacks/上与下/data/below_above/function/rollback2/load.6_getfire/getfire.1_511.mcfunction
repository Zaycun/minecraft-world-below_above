scoreboard players operation #rollback2_fire dummy = #backup2_Fire dummy
scoreboard players remove #rollback2_fire dummy 255
execute store result storage below_above:rollback2 fire int 1 run scoreboard players get #rollback2_fire dummy
scoreboard players reset #rollback2_fire dummy
function below_above:rollback2/load.6_getfire/getfire.2_511 with storage below_above:rollback2