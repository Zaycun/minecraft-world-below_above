scoreboard players enable @a config.trigger

execute unless entity @a[scores={config.trigger=1..16}] run return fail

execute as @a if score @s config.trigger matches 1 run return run function below_above:open_menu_tip/trigger
execute as @a if score @s config.trigger matches 2 run return run function below_above:dialog/statistics.1
execute as @a if score @s config.trigger matches 3 run return run function below_above:dialog/backup_and_reset.1
execute as @a if score @s config.trigger matches 4 run return run function below_above:dialog/setting.1
execute as @a if score @s config.trigger matches 5 run return run function below_above:dialog/rules.1
execute as @a if score @s config.trigger matches 6 run return run function below_above:dialog/about.1

execute as @a if score @s config.trigger matches 7 run return run function below_above:backup1/prepare
execute as @a if score @s config.trigger matches 8 run return run function below_above:rollback1/test

execute as @a if score @s config.trigger matches 9 run return run function below_above:backup2/prepare
execute as @a if score @s config.trigger matches 10 run return run function below_above:rollback2/test

execute as @a if score @s config.trigger matches 11 run return run function below_above:backup3/prepare
execute as @a if score @s config.trigger matches 12 run return run function below_above:rollback3/test
execute as @a if score @s config.trigger matches 13 run return run function below_above:rollback_reset/reset.1

execute as @a if score @s config.trigger matches 14 run return run function below_above:setting/effect_night_vision
execute as @a if score @s config.trigger matches 15 run return run function below_above:setting/faster_mining
execute as @a if score @s config.trigger matches 16 run return run function below_above:setting/effect_saturation

scoreboard players reset @s config.trigger