

data remove storage below_above:present_advancements adventure
data remove storage below_above:present_advancements end
data remove storage below_above:present_advancements husbandry
data remove storage below_above:present_advancements nether
data remove storage below_above:present_advancements story

advancement revoke @s from minecraft:adventure/root
advancement revoke @s from minecraft:end/root
advancement revoke @s from minecraft:husbandry/root
advancement revoke @s from minecraft:nether/root
advancement revoke @s from minecraft:story/root
advancement revoke @s from below_above:adventure/root
advancement revoke @s from below_above:end/root
advancement revoke @s from below_above:husbandry/root
advancement revoke @s from below_above:nether/root
advancement revoke @s from below_above:story/root

