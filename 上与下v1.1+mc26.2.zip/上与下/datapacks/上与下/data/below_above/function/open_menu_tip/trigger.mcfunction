scoreboard players reset @s config.trigger
tag @s add opened_menu