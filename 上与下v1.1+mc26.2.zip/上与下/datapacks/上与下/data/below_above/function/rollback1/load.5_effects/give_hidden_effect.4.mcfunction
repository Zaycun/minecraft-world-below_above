
execute if score #rollback_hidden_effect_seconds dummy matches 1.. store result storage below_above:rollback1 hidden_effect_seconds int 1 \
  run scoreboard players operation #rollback_hidden_effect_seconds dummy /= 20 dummy
execute if score #rollback_hidden_effect_seconds dummy matches -1 run data modify storage below_above:rollback1 hidden_effect_seconds set value "infinite"
#隐藏效果时长存入命令存储

data modify storage below_above:rollback1 hidden_effect_amplifier set value 0
$execute store result score #rollback_hidden_effect_amplifier dummy run data get storage below_above:backup1 active_effects[$(effects_count)].hidden_effect.amplifier
execute if score #rollback_hidden_effect_amplifier dummy matches ..-1 run scoreboard players add #rollback_hidden_effect_amplifier dummy 256
execute store result storage below_above:rollback1 hidden_effect_amplifier int 1 run scoreboard players get #rollback_hidden_effect_amplifier dummy
#隐藏效果等级存入命令存储

data modify storage below_above:rollback1 hidden_effect_id set value "none"
$data modify storage below_above:rollback1 hidden_effect_id set \
  from storage below_above:backup1 active_effects.[$(effects_count)].id
#将隐藏效果id存入命令存储

scoreboard players set #is_show_particles dummy 1
$execute if data storage below_above:backup1 active_effects[0].hidden_effect.show_particles store result score #is_show_particles dummy run data get storage below_above:backup1 active_effects[$(effects_count)].hidden_effect.show_particles
execute if score #is_show_particles dummy matches 0 run return run function below_above:rollback1/load.5_effects/give_hidden_effect.5_true with storage below_above:rollback1

execute as @s run function below_above:rollback1/load.5_effects/give_hidden_effect.5_false with storage below_above:rollback1