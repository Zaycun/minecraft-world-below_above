
data remove storage below_above:present_advancements husbandry
#移除现在的进度

execute store result score #rollback_advancements_number dummy run data get storage below_above:backup1_advancements husbandry
execute if score #rollback_advancements_number dummy matches ..0 run return fail
scoreboard players remove #rollback_advancements_number dummy 1
#获取备份husbandry进度数量

data modify storage below_above:rollback1 advancements_count set value 0
scoreboard players set #rollback_advancements_count dummy 0
function below_above:rollback1/load.8_advancements/husbandry.2 with storage below_above:rollback1
#将计数设为0