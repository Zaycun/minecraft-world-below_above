scoreboard players operation #rollback1_fire dummy = #backup1_Fire dummy
scoreboard players remove #rollback1_fire dummy 255
execute store result storage below_above:rollback1 fire int 1 run scoreboard players get #rollback1_fire dummy
scoreboard players reset #rollback1_fire dummy
function below_above:rollback1/load.6_getfire/getfire.2_511 with storage below_above:rollback1