$data modify storage below_above:rollback1 recipe_id set from storage below_above:backup1 recipeBook[$(recipes_count)]

function below_above:rollback1/load.7_recipes/give_recipe.4 with storage below_above:rollback1