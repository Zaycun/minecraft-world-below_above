data modify storage below_above:rollback1 advancements_husbandry_id set value none
$data modify storage below_above:rollback1 advancement_husbandry_id set from storage below_above:backup1_advancements husbandry[$(advancements_count)]
function below_above:rollback1/load.8_advancements/husbandry.3 with storage below_above:rollback1
#获取当前计数的进度id