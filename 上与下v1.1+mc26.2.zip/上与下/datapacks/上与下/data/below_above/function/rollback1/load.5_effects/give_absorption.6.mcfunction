$damage @s $(damage2) minecraft:generic_kill
data remove storage below_above:rollback1 damage2

execute if score #rollback_effects_count dummy >= #rollback_effects_number dummy run return \
  run function below_above:rollback1/load.5_effects/give_effect.4
#结束

scoreboard players add #rollback_effects_count dummy 1
execute store result storage below_above:rollback1 effects_count int 1 \
  run scoreboard players get #rollback_effects_count dummy
function below_above:rollback1/load.5_effects/give_effect.2 with storage below_above:rollback1
