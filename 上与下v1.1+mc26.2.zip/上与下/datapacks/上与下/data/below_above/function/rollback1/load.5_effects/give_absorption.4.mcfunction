$effect give @s minecraft:absorption $(effect_seconds) $(effect_amplifier) false

execute if score #backup1_Health dummy >= 2000000000 dummy \
  run return run function below_above:rollback1/load.5_effects/give_absorption.5
schedule function below_above:rollback1/load.5_effects/give_absorption.5 7t append

