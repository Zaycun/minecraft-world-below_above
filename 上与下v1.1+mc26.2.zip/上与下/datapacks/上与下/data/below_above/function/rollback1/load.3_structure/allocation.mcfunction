execute if score level dummy matches 0 run function below_above:rollback1/load.3_structure/level0
execute if score level dummy matches 1 run function below_above:rollback1/load.3_structure/level1
execute if score level dummy matches 2 run function below_above:rollback1/load.3_structure/level2
execute if score level dummy matches 3 run function below_above:rollback1/load.3_structure/level3
execute if score level dummy matches 4 run function below_above:rollback1/load.3_structure/level4
execute if score level dummy matches 5 run function below_above:rollback1/load.3_structure/level5
execute if score level dummy matches 6 run function below_above:rollback1/load.3_structure/level6
#结构重置