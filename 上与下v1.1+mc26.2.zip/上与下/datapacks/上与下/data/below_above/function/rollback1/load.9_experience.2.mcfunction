$experience add @s $(xp) points

function below_above:rollback1/load.10_container