gamemode survival @s
scoreboard players reset #present_Fire
attribute @s minecraft:block_interaction_range modifier remove below_above:remove_block_range
attribute @s entity_interaction_range modifier remove below_above:remove_entity_range
execute unless score level dummy matches 6 run gamerule minecraft:natural_health_regeneration true
gamerule minecraft:show_advancement_messages true
gamerule minecraft:fall_damage true
gamerule minecraft:drowning_damage true
gamerule minecraft:fire_damage true
gamerule minecraft:freeze_damage true
tellraw @s {text:"已回档至备份1",color:"#fb6f6f"}
scoreboard players set #is_loading dummy 0