effect clear @s
execute store result score #rollback_effects_number dummy run data get storage below_above:backup1 active_effects
scoreboard players remove #rollback_effects_number dummy 1
#效果数量存入记分板
data modify storage below_above:rollback1 effects_count set value 0
scoreboard players set #rollback_effects_count dummy 0
function below_above:rollback1/load.5_effects/give_hidden_effect.3 with storage below_above:rollback1

