$damage @a[tag=player,limit=1] $(damage1) minecraft:generic_kill
data remove storage below_above:rollback1 damage1

function below_above:rollback1/load.5_effects/give_hidden_effect.1