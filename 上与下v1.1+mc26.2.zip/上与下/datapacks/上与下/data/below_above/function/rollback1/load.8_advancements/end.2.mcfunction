data modify storage below_above:rollback1 advancements_end_id set value none
$data modify storage below_above:rollback1 advancement_end_id set from storage below_above:backup1_advancements end[$(advancements_count)]
function below_above:rollback1/load.8_advancements/end.3 with storage below_above:rollback1
#获取当前计数的进度id