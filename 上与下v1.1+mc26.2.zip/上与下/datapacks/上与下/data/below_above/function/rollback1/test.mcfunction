scoreboard players reset @s config.trigger

execute if score #has_backup1 dummy matches 1 run function below_above:rollback1/load.1
execute if score #has_backup1 dummy matches 0 run tellraw @s {text:"备份1不存在！请先创建备份1后再试！",color:"red"}