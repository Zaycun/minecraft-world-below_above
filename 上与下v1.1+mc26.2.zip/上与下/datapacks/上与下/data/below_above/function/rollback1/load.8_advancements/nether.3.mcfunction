$advancement grant @s only minecraft:nether/$(advancement_nether_id)
$advancement grant @s only below_above:nether/$(advancement_nether_id)

execute if score #rollback_advancements_count dummy >= #rollback_advancements_number dummy run return fail

scoreboard players add #rollback_advancements_count dummy 1
execute store result storage below_above:rollback1 advancements_count int 1 run scoreboard players get #rollback_advancements_count dummy
function below_above:rollback1/load.8_advancements/nether.2 with storage below_above:rollback1