data modify storage below_above:rollback1 hidden_effect_seconds set value 0
$execute store result score #rollback_hidden_effect_seconds dummy \
  run data get storage below_above:backup1 active_effects[$(effects_count)].hidden_effect.duration


execute if score #rollback_hidden_effect_seconds dummy matches 0 run return run function below_above:rollback1/load.5_effects/give_hidden_effect.6
function below_above:rollback1/load.5_effects/give_hidden_effect.4 with storage below_above:rollback1


