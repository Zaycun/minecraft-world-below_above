scoreboard players set #is_loading dummy 1
clear @a
effect clear @a
experience add @a[tag=!player] -2147483647 points
attribute @s minecraft:block_interaction_range modifier add below_above:remove_block_range -1 add_multiplied_total
attribute @s minecraft:entity_interaction_range modifier add below_above:remove_entity_range -1 add_multiplied_total
recipe take @s *
gamerule minecraft:natural_health_regeneration false
gamerule minecraft:show_advancement_messages false
gamerule minecraft:fall_damage false
gamerule minecraft:drowning_damage false
gamerule minecraft:fire_damage false
gamerule minecraft:freeze_damage false

effect give @a minecraft:instant_health 1 252 true

scoreboard players add #level_rollback_times dummy 1
scoreboard players add #total_rollback_times dummy 1

data modify storage below_above:rollback1 pos_x set from storage below_above:backup1 Pos[0]
data modify storage below_above:rollback1 pos_y set from storage below_above:backup1 Pos[1]
data modify storage below_above:rollback1 pos_z set from storage below_above:backup1 Pos[2]
data modify storage below_above:rollback1 rot_y set from storage below_above:backup1 Rotation[0]
data modify storage below_above:rollback1 rot_x set from storage below_above:backup1 Rotation[1]
data modify storage below_above:rollback1 dimension set from storage below_above:backup1 Dimension
data modify storage below_above:rollback1 respawn_pos_x set from storage below_above:backup1 respawn.pos[0]
data modify storage below_above:rollback1 respawn_pos_y set from storage below_above:backup1 respawn.pos[1]
data modify storage below_above:rollback1 respawn_pos_z set from storage below_above:backup1 respawn.pos[2]
data modify storage below_above:rollback1 respawn_rot_y set from storage below_above:backup1 respawn.yaw
data modify storage below_above:rollback1 respawn_rot_x set from storage below_above:backup1 respawn.pitch
data modify storage below_above:rollback1 respawn_dimension set from storage below_above:backup1 respawn.dimension

execute store result score #present_Fire dummy run data get entity @s Fire

execute if score #backup1_pose dummy matches 0 run function below_above:rollback1/load.3_structure/allocation
execute if score #backup1_pose dummy matches 1 run function below_above:rollback1/load.2_pose/sneaking with storage below_above:rollback1
execute if score #backup1_pose dummy matches 2 run function below_above:rollback1/load.2_pose/crawling with storage below_above:rollback1
