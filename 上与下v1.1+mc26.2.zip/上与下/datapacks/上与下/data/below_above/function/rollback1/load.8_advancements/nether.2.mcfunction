data modify storage below_above:rollback1 advancements_nether_id set value none
$data modify storage below_above:rollback1 advancement_nether_id set from storage below_above:backup1_advancements nether[$(advancements_count)]
function below_above:rollback1/load.8_advancements/nether.3 with storage below_above:rollback1
#获取当前计数的进度id