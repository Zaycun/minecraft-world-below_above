execute if data storage below_above:rollback1 {effect_amplifier:0} \
  run scoreboard players set #rollback_max_absorption dummy 400000000
execute if data storage below_above:rollback1 {effect_amplifier:1} \
  run scoreboard players set #rollback_max_absorption dummy 800000000
execute if data storage below_above:rollback1 {effect_amplifier:2} \
  run scoreboard players set #rollback_max_absorption dummy 1200000000
execute if data storage below_above:rollback1 {effect_amplifier:3} \
  run scoreboard players set #rollback_max_absorption dummy 1600000000
execute if data storage below_above:rollback1 {effect_amplifier:4} \
  run scoreboard players set #rollback_max_absorption dummy 2000000000

scoreboard players operation #rollback1_damage.2 dummy = #rollback_max_absorption dummy

execute store result storage below_above:rollback1 damage2 float 0.00000001 \
  run scoreboard players operation #rollback1_damage.2 dummy -= #backup1_AbsorptionAmount dummy
scoreboard players reset #rollback1_damage.2 dummy
schedule function below_above:rollback1/load.5_effects/give_absorption.3 1t append

