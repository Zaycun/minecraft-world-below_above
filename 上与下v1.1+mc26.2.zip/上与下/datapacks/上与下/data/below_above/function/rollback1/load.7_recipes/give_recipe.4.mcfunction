$recipe give @s $(recipe_id)

execute if score #rollback_recipes_count dummy >= #rollback_recipes_number dummy run return \
 run function below_above:rollback1/load.8_advancements
#结束

scoreboard players add #rollback_recipes_count dummy 1
execute store result storage below_above:rollback1 recipes_count int 1 \
  run scoreboard players get #rollback_recipes_count dummy
function below_above:rollback1/load.7_recipes/give_recipe.3 with storage below_above:rollback1