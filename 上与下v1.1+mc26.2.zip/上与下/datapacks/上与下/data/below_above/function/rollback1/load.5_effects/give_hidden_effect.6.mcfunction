execute if score #rollback_effects_count dummy >= #rollback_effects_number dummy run return \
  run function below_above:rollback1/load.5_effects/give_effect.1
#隐藏效果执行完


#未完，继续给予隐藏效果
scoreboard players add #rollback_effects_count dummy 1
execute store result storage below_above:rollback1 effects_count int 1 \
  run scoreboard players get #rollback_effects_count dummy



function below_above:rollback1/load.5_effects/give_hidden_effect.3 with storage below_above:rollback1