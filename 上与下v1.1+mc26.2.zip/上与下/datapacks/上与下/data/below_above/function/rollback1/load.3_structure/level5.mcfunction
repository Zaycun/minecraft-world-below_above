execute in minecraft:overworld run teleport @e[x=-89,y=-9,z=87,dx=19,dy=11,dz=19,type=!minecraft:player] -86 -128 90
execute in minecraft:overworld run kill @e[x=-85.5,y=-128,z=90.5,distance=..1]

execute in minecraft:overworld run place template below_above:backup1_subtle -89 -9 87 none none 1 0 strict
execute in minecraft:overworld run setblock -89 0 105 minecraft:grass_block

execute if score #backup1_Health dummy < 2000000000 dummy run return \
  run function below_above:rollback1/load.4_health.1
#不满血，执行函数

schedule function below_above:rollback1/load.5_effects/give_hidden_effect.1 2t append
#满血，跳过一项