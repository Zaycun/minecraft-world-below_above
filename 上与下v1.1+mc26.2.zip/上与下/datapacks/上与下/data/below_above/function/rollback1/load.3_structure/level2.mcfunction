execute in minecraft:overworld run teleport @e[x=-144,y=-49,z=0,dx=15,dy=92,dz=15,type=!minecraft:player] -136 -128 7
execute in minecraft:overworld run kill @e[x=-136.5,y=-128,z=7.5,distance=..1]

execute in minecraft:overworld run place template below_above:backup1_mob_lab.1 -144 -49 0 none none 1 0 strict
execute in minecraft:overworld run place template below_above:backup1_mob_lab.2 -144 -3 0 none none 1 0 strict
execute in minecraft:overworld run setblock -144 -6 14 minecraft:bedrock
execute in minecraft:overworld run setblock -144 41 14 minecraft:air

schedule function below_above:rollback_entity_data/level2.1 2t append

execute if score #backup1_Health dummy < 2000000000 dummy run return \
  run function below_above:rollback1/load.4_health.1
#不满血，执行函数

schedule function below_above:rollback1/load.5_effects/give_hidden_effect.1 2t append
#满血，跳过一项