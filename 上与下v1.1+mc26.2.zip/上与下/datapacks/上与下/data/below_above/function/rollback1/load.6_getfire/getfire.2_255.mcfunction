$item replace entity @s armor.head with minecraft:knowledge_book\
  [enchantments={"below_above:get_fire1":$(fire),binding_curse:1},!item_name,!lore,tooltip_display={hide_tooltip:true},item_model="minecraft:air"] 1
schedule function below_above:rollback1/load.6_getfire/getfire.3 2t append