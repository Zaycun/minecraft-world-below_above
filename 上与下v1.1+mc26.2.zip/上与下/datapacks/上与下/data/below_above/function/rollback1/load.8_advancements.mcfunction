advancement revoke @s everything
advancement grant @s only below_above:first_join
execute as @s run function below_above:rollback1/load.8_advancements/adventure.1
execute as @s run function below_above:rollback1/load.8_advancements/end.1
execute as @s run function below_above:rollback1/load.8_advancements/husbandry.1
execute as @s run function below_above:rollback1/load.8_advancements/nether.1
execute as @s run function below_above:rollback1/load.8_advancements/story.1
schedule function below_above:stopsound 2t append
schedule function below_above:stopsound 5t append
schedule function below_above:stopsound 10t append

function below_above:rollback1/load.9_experience.1