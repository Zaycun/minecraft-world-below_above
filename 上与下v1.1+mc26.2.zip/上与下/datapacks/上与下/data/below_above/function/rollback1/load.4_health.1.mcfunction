scoreboard players operation #rollback1_damage.1 dummy = 2000000000 dummy
execute store result storage below_above:rollback1 damage1 float 0.00000001 \
  run scoreboard players operation #rollback1_damage.1 dummy -= #backup1_Health dummy

scoreboard players reset #rollback1_damage.1 dummy
schedule function below_above:rollback1/load.4_health.2 2t append