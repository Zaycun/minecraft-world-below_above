gamemode survival @s

execute if score #backup1_Fire dummy matches 1..255 run return run function below_above:rollback1/load.6_getfire/getfire.1_255
execute if score #backup1_Fire dummy matches 256..511 run return run function below_above:rollback1/load.6_getfire/getfire.1_511

function below_above:rollback1/load.7_recipes/give_recipe.2