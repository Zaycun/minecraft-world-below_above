execute in below_above:backup3_structure run setblock -130 -6 0 minecraft:redstone_block
execute in below_above:backup3_structure run setblock -130 41 0 minecraft:redstone_block
#保存备份结构

schedule function below_above:re_backup_structure/level2/backup3.3 2t