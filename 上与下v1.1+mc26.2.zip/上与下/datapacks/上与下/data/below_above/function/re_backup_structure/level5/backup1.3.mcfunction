execute in below_above:backup1_structure run setblock -89 0 105 minecraft:grass_block
execute in below_above:backup1_structure run forceload remove -96 80 -65 111