execute in below_above:backup1_structure run setblock -80 11 30 minecraft:air
execute in below_above:backup1_structure run forceload remove -80 16 -65 31