execute in below_above:backup1_structure run setblock -127 4 58 minecraft:air
execute in below_above:backup1_structure run forceload remove -128 48 -113 63