execute in below_above:backup2_structure run setblock -55 45 -39 minecraft:bedrock
execute in below_above:backup2_structure run setblock -55 95 -39 minecraft:air
execute in below_above:backup2_structure run forceload remove -96 -80 -49 -33