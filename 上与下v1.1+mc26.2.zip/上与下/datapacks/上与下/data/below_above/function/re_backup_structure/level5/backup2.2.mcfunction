execute in below_above:backup2_structure run setblock -71 0 105 minecraft:redstone_block
#保存备份结构

schedule function below_above:re_backup_structure/level5/backup2.3 2t