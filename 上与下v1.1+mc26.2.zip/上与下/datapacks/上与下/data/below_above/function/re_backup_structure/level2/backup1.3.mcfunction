execute in below_above:backup1_structure run setblock -144 -6 14 minecraft:bedrock
execute in below_above:backup1_structure run setblock -144 41 14 minecraft:air
execute in below_above:backup1_structure run forceload remove -144 0 -129 15