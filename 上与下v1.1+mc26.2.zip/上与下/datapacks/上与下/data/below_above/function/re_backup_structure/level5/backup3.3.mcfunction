execute in below_above:backup3_structure run setblock -71 0 87 minecraft:air
execute in below_above:backup3_structure run forceload remove -96 80 -65 111