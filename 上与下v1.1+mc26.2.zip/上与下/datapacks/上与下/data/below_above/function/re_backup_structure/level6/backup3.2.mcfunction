execute in below_above:backup3_structure run setblock 2 -8 -2 minecraft:redstone_block
execute in below_above:backup3_structure run setblock 2 -3 -2 minecraft:redstone_block
#保存备份结构

schedule function below_above:re_backup_structure/level6/backup3.3 2t