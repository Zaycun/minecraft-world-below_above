execute if score level dummy matches 0 if score #has_backup1 dummy matches 1 run function below_above:re_backup_structure/level0/backup1.1
execute if score level dummy matches 0 if score #has_backup2 dummy matches 1 run function below_above:re_backup_structure/level0/backup2.1
execute if score level dummy matches 0 if score #has_backup3 dummy matches 1 run function below_above:re_backup_structure/level0/backup3.1

execute if score level dummy matches 1 if score #has_backup1 dummy matches 1 run function below_above:re_backup_structure/level1/backup1.1
execute if score level dummy matches 1 if score #has_backup2 dummy matches 1 run function below_above:re_backup_structure/level1/backup2.1
execute if score level dummy matches 1 if score #has_backup3 dummy matches 1 run function below_above:re_backup_structure/level1/backup3.1

execute if score level dummy matches 2 if score #has_backup1 dummy matches 1 run function below_above:re_backup_structure/level2/backup1.1
execute if score level dummy matches 2 if score #has_backup2 dummy matches 1 run function below_above:re_backup_structure/level2/backup2.1
execute if score level dummy matches 2 if score #has_backup3 dummy matches 1 run function below_above:re_backup_structure/level2/backup3.1

execute if score level dummy matches 3 if score #has_backup1 dummy matches 1 run function below_above:re_backup_structure/level3/backup1.1
execute if score level dummy matches 3 if score #has_backup2 dummy matches 1 run function below_above:re_backup_structure/level3/backup2.1
execute if score level dummy matches 3 if score #has_backup3 dummy matches 1 run function below_above:re_backup_structure/level3/backup3.1

execute if score level dummy matches 4 if score #has_backup1 dummy matches 1 run function below_above:re_backup_structure/level4/backup1.1
execute if score level dummy matches 4 if score #has_backup2 dummy matches 1 run function below_above:re_backup_structure/level4/backup2.1
execute if score level dummy matches 4 if score #has_backup3 dummy matches 1 run function below_above:re_backup_structure/level4/backup3.1

execute if score level dummy matches 5 if score #has_backup1 dummy matches 1 run function below_above:re_backup_structure/level5/backup1.1
execute if score level dummy matches 5 if score #has_backup2 dummy matches 1 run function below_above:re_backup_structure/level5/backup2.1
execute if score level dummy matches 5 if score #has_backup3 dummy matches 1 run function below_above:re_backup_structure/level5/backup3.1

execute if score level dummy matches 6 if score #has_backup1 dummy matches 1 run function below_above:re_backup_structure/level6/backup1.1
execute if score level dummy matches 6 if score #has_backup2 dummy matches 1 run function below_above:re_backup_structure/level6/backup2.1
execute if score level dummy matches 6 if score #has_backup3 dummy matches 1 run function below_above:re_backup_structure/level6/backup3.1

scoreboard players set #is_loading dummy 0