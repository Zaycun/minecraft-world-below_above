execute in below_above:backup1_structure run setblock -144 -6 14 minecraft:redstone_block
execute in below_above:backup1_structure run setblock -144 41 14 minecraft:redstone_block
#保存备份结构

schedule function below_above:re_backup_structure/level2/backup1.3 2t