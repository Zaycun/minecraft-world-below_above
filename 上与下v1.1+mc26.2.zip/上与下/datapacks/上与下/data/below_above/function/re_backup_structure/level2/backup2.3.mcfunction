execute in below_above:backup2_structure run setblock -130 -6 14 minecraft:bedrock
execute in below_above:backup2_structure run setblock -130 41 14 minecraft:air
execute in below_above:backup2_structure run forceload remove -144 0 -129 15