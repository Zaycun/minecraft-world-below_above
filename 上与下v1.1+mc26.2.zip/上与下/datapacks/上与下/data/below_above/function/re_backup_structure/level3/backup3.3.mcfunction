execute in below_above:backup3_structure run setblock -55 45 -75 minecraft:bedrock
execute in below_above:backup3_structure run setblock -55 95 -75 minecraft:air
execute in below_above:backup3_structure run forceload remove -96 -80 -49 -33