execute in below_above:backup2_structure run setblock -55 45 -39 minecraft:redstone_block
execute in below_above:backup2_structure run setblock -55 95 -39 minecraft:redstone_block
#保存备份结构

schedule function below_above:re_backup_structure/level3/backup2.3 2t