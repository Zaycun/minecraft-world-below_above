execute in below_above:backup2_structure run setblock -66 11 30 minecraft:air
execute in below_above:backup2_structure run forceload remove -80 16 -65 31