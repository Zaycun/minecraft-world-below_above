execute in below_above:backup1_structure run setblock -127 4 58 minecraft:redstone_block
#保存备份结构

schedule function below_above:re_backup_structure/level1/backup1.3 2t