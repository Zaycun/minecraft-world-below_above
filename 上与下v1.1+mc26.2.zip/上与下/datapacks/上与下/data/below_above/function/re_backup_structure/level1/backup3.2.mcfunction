execute in below_above:backup3_structure run setblock -115 4 52 minecraft:redstone_block
#保存备份结构

schedule function below_above:re_backup_structure/level1/backup3.3 2t