execute in below_above:backup3_structure run setblock -66 11 16 minecraft:redstone_block
#保存备份结构

schedule function below_above:re_backup_structure/level0/backup3.3 2t