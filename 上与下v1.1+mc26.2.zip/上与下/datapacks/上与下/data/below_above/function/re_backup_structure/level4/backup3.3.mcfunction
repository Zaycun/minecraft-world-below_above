execute in below_above:backup3_structure run setblock -8 9 53 minecraft:air
execute in below_above:backup3_structure run forceload remove -32 48 -1 79