execute in below_above:backup1_structure run setblock -91 45 -39 minecraft:bedrock
execute in below_above:backup1_structure run setblock -91 95 -39 minecraft:air
execute in below_above:backup1_structure run forceload remove -96 -80 -49 -33