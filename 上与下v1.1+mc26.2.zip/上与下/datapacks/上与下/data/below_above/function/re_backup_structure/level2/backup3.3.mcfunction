execute in below_above:backup3_structure run setblock -130 -6 0 minecraft:bedrock
execute in below_above:backup3_structure run setblock -130 41 0 minecraft:air
execute in below_above:backup3_structure run forceload remove -144 0 -129 15