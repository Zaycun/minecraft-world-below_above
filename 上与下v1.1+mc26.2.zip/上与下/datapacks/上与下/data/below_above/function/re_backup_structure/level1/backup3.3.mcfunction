execute in below_above:backup3_structure run setblock -115 4 52 minecraft:air
execute in below_above:backup3_structure run forceload remove -128 48 -113 63