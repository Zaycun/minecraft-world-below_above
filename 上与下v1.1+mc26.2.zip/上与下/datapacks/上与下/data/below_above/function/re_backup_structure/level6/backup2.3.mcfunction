execute in below_above:backup2_structure run place template below_above:backup2_above_and_below.1 -12 -31 -12 none none 1 0 strict
execute in below_above:backup2_structure run place template below_above:backup2_above_and_below.2 -12 17 -12 none none 1 0 strict
execute in below_above:backup2_structure run forceload remove -16 -16 15 15