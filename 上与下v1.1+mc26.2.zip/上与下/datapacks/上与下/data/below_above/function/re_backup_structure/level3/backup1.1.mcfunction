execute in below_above:backup1_structure run forceload add -96 -80 -49 -33
#强加载结构备份维度

schedule function below_above:re_backup_structure/level3/backup1.2 4t append
#必须4t