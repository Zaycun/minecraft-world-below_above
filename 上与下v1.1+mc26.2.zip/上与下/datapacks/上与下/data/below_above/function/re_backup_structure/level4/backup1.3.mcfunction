execute in below_above:backup1_structure run setblock -24 4 73 minecraft:air
execute in below_above:backup1_structure run forceload remove -32 48 -1 79