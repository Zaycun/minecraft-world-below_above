execute in below_above:backup2_structure run setblock -66 11 30 minecraft:redstone_block
#保存备份结构

schedule function below_above:re_backup_structure/level0/backup2.3 2t