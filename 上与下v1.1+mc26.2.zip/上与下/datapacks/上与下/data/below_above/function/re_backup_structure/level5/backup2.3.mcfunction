execute in below_above:backup2_structure run setblock -71 0 105 minecraft:bedrock
execute in below_above:backup2_structure run forceload remove -96 80 -65 111