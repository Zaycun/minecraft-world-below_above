$execute if score #has_backup1 dummy matches 1 run data modify storage below_above:backup_and_reset rollback1_text set value "$(backup1_clock_h):$(backup1_clock_m):$(backup1_clock_s)"

$execute if score #has_backup2 dummy matches 1 run data modify storage below_above:backup_and_reset rollback2_text set value "$(backup2_clock_h):$(backup2_clock_m):$(backup2_clock_s)"

$execute if score #has_backup3 dummy matches 1 run data modify storage below_above:backup_and_reset rollback3_text set value "$(backup3_clock_h):$(backup3_clock_m):$(backup3_clock_s)"

function below_above:dialog/backup_and_reset.7 with storage below_above:backup_and_reset