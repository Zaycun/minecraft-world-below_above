$dialog show @s \
  {\
    type:"multi_action",\
    after_action:none,\
    columns:1,\
    pause:false,\
    title:{text:"设置"},\
    body:{\
      type:"plain_message",\
      contents:{\
        text:""\
      }\
    },\
    actions:[\
      {\
        label: "夜视效果：$(effect_night_vision)",\
        width: 100,\
        tooltip: {text: "夜视"},\
        action: {\
          type: "run_command",\
          command: "trigger config.trigger set 14"\
        }\
      },\
      {\
        label: "挖掘速度提升：$(faster_mining)",\
        width: 100,\
        tooltip: {text: "效果急迫 IV + 属性方块破坏速度+4"},\
        action: {\
          type: "run_command",\
          command: "trigger config.trigger set 15"\
        }\
      },\
      {\
        label: "饱和效果：开",\
        width: 100,\
        tooltip: {text: "饱和"},\
        action: {\
          type: "run_command",\
          command: "trigger config.trigger set 16"\
        }\
      }\
    ],\
    exit_action:{\
      label: "返回",\
      action:{\
        type: "show_dialog",\
        dialog: "below_above:config"\
       }\
    }\
  }