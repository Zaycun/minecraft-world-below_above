function below_above:dialog/backup_and_reset.3
function below_above:dialog/backup_and_reset.4
function below_above:dialog/backup_and_reset.5


data modify storage below_above:backup_and_reset backup1_clock_h set from storage below_above:backup1 clock_hour
data modify storage below_above:backup_and_reset backup1_clock_m set from storage below_above:backup1 clock_minute
data modify storage below_above:backup_and_reset backup1_clock_s set from storage below_above:backup1 clock_second

data modify storage below_above:backup_and_reset backup2_clock_h set from storage below_above:backup2 clock_hour
data modify storage below_above:backup_and_reset backup2_clock_m set from storage below_above:backup2 clock_minute
data modify storage below_above:backup_and_reset backup2_clock_s set from storage below_above:backup2 clock_second

data modify storage below_above:backup_and_reset backup3_clock_h set from storage below_above:backup3 clock_hour
data modify storage below_above:backup_and_reset backup3_clock_m set from storage below_above:backup3 clock_minute
data modify storage below_above:backup_and_reset backup3_clock_s set from storage below_above:backup3 clock_second



execute unless score #has_backup1 dummy matches 1 run data modify storage below_above:backup_and_reset rollback1_text set value ""
execute unless score #has_backup2 dummy matches 1 run data modify storage below_above:backup_and_reset rollback2_text set value ""
execute unless score #has_backup3 dummy matches 1 run data modify storage below_above:backup_and_reset rollback3_text set value ""


function below_above:dialog/backup_and_reset.6 with storage below_above:backup_and_reset
