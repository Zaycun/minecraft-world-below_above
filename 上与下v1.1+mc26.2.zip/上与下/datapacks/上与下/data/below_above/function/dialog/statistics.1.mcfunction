scoreboard players reset @s config.trigger

execute if score level dummy matches 0..6 run function below_above:dialog/statistics.2
#数据计算



execute if score level dummy matches -1 run return run tellraw @s {text:"请在游戏开始后再试！",color:"red"}
execute if score level dummy matches 0 run return run function below_above:dialog/statistics_level0 with storage below_above:statistics
execute if score level dummy matches 1 run return run function below_above:dialog/statistics_level1 with storage below_above:statistics
execute if score level dummy matches 2 run return run function below_above:dialog/statistics_level2 with storage below_above:statistics
execute if score level dummy matches 3 run return run function below_above:dialog/statistics_level3 with storage below_above:statistics
execute if score level dummy matches 4 run return run function below_above:dialog/statistics_level4 with storage below_above:statistics
execute if score level dummy matches 5 run return run function below_above:dialog/statistics_level5 with storage below_above:statistics
execute if score level dummy matches 6 run return run function below_above:dialog/statistics_level6 with storage below_above:statistics
execute if score level dummy matches 7 run return run function below_above:dialog/statistics_win with storage below_above:statistics