scoreboard players reset @s config.trigger

function below_above:dialog/rules.2