execute store result score #level_time_taken dummy run stopwatch query below_above:level_time_taken 1000
scoreboard players operation #level_time_taken_h dummy = #level_time_taken dummy
scoreboard players operation #level_time_taken_ms dummy = #level_time_taken_h dummy
scoreboard players operation #level_time_taken_h dummy /= 3600000 dummy
scoreboard players operation #level_time_taken_ms dummy %= 3600000 dummy
scoreboard players operation #level_time_taken_m dummy = #level_time_taken_ms dummy
scoreboard players operation #level_time_taken_m dummy /= 60000 dummy
scoreboard players operation #level_time_taken_ms dummy %= 60000 dummy
scoreboard players operation #level_time_taken_s dummy = #level_time_taken_ms dummy
scoreboard players operation #level_time_taken_s dummy /= 1000 dummy
scoreboard players operation #level_time_taken_ms dummy %= 1000 dummy
execute store result storage below_above:statistics level_time_taken_h int 1 run scoreboard players get #level_time_taken_h dummy
execute store result storage below_above:statistics level_time_taken_m int 1 run scoreboard players get #level_time_taken_m dummy
execute store result storage below_above:statistics level_time_taken_s int 1 run scoreboard players get #level_time_taken_s dummy
execute store result storage below_above:statistics level_time_taken_ms int 1 run scoreboard players get #level_time_taken_ms dummy

execute if score #level_time_taken_ms dummy matches 0..9 run data modify storage below_above:statistics level_time_taken_placeholder set value "00"
execute if score #level_time_taken_ms dummy matches 10..99 run data modify storage below_above:statistics level_time_taken_placeholder set value "0"
execute if score #level_time_taken_ms dummy matches 100..999 run data modify storage below_above:statistics level_time_taken_placeholder set value ""
#本关用时

execute store result score #total_time_taken dummy run stopwatch query below_above:total_time_taken 1000
scoreboard players operation #total_time_taken_h dummy = #total_time_taken dummy
scoreboard players operation #total_time_taken_ms dummy = #total_time_taken_h dummy
scoreboard players operation #total_time_taken_h dummy /= 3600000 dummy
scoreboard players operation #total_time_taken_ms dummy %= 3600000 dummy
scoreboard players operation #total_time_taken_m dummy = #total_time_taken_ms dummy
scoreboard players operation #total_time_taken_m dummy /= 60000 dummy
scoreboard players operation #total_time_taken_ms dummy %= 60000 dummy
scoreboard players operation #total_time_taken_s dummy = #total_time_taken_ms dummy
scoreboard players operation #total_time_taken_s dummy /= 1000 dummy
scoreboard players operation #total_time_taken_ms dummy %= 1000 dummy
execute store result storage below_above:statistics total_time_taken_h int 1 run scoreboard players get #total_time_taken_h dummy
execute store result storage below_above:statistics total_time_taken_m int 1 run scoreboard players get #total_time_taken_m dummy
execute store result storage below_above:statistics total_time_taken_s int 1 run scoreboard players get #total_time_taken_s dummy
execute store result storage below_above:statistics total_time_taken_ms int 1 run scoreboard players get #total_time_taken_ms dummy

execute if score #total_time_taken_ms dummy matches 0..9 run data modify storage below_above:statistics total_time_taken_placeholder set value "00"
execute if score #total_time_taken_ms dummy matches 10..99 run data modify storage below_above:statistics total_time_taken_placeholder set value "0"
execute if score #total_time_taken_ms dummy matches 100..999 run data modify storage below_above:statistics total_time_taken_placeholder set value ""
#总用时

execute store result storage below_above:statistics level_backup_times int 1 run scoreboard players get #level_backup_times dummy
execute store result storage below_above:statistics total_backup_times int 1 run scoreboard players get #total_backup_times dummy
#备份次数

execute store result storage below_above:statistics level_rollback_times int 1 run scoreboard players get #level_rollback_times dummy
execute store result storage below_above:statistics total_rollback_times int 1 run scoreboard players get #total_rollback_times dummy
#回档次数