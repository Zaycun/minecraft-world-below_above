scoreboard players reset @s config.trigger

execute if score #setting_night_vision dummy matches 0 run data modify storage below_above:setting effect_night_vision set value "关"
execute if score #setting_night_vision dummy matches 1 run data modify storage below_above:setting effect_night_vision set value "开"
execute if score #setting_faster_mining dummy matches 0 run data modify storage below_above:setting faster_mining set value "关"
execute if score #setting_faster_mining dummy matches 1 run data modify storage below_above:setting faster_mining set value "开"

execute if entity @s[tag=player] run function below_above:dialog/setting.2 with storage below_above:setting
execute if entity @s[tag=!player] run tellraw @s {"text":"非玩家无法执行此操作！","color":"red"}