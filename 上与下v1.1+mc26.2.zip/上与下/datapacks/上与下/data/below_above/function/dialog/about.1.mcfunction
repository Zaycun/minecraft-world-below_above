scoreboard players reset @s config.trigger

function below_above:dialog/about.2 with storage below_above:global