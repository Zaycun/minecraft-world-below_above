scoreboard players reset @s config.trigger


execute if score is_starting dummy matches 0 run return run tellraw @s {"text":"请在游戏开始后再试！","color":"red"}
execute if score #is_loading dummy matches 0 if score is_starting dummy matches 1 if entity @s[tag=player] run return run function below_above:dialog/backup_and_reset.2
execute if score #is_loading dummy matches 1 if score is_starting dummy matches 1 run return run tellraw @s {"text":"数据包加载中，请稍后再试！","color":"red"}
execute if score is_starting dummy matches 1 if entity @s[tag=!player] run tellraw @s {"text":"非玩家无法执行此操作！","color":"red"}