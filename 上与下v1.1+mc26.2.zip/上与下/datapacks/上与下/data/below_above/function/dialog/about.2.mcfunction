$dialog show @s \
  {\
    type:"minecraft:notice",\
    pause:false,\
    action:{label:"返回",action:{type:"show_dialog",dialog:"below_above:config"}},\
    title:{text:"关于"},\
    body:{\
      type:"plain_message",\
      contents:[\
        {\
          text:"地图：",color:"#b1f7f2",extra:[{text:"上与下\n",color:"#dcb69a"}]\
        },\
        {\
          text:"密室设计：",color:"#b1f7f2",extra:[{text:"Zaycun\n",color:"#e0e0e0",hover_event:{action:show_text,value:"UUID: d6c989c3-b6d9-4644-b42d-5b3f83f07ee2"}}]\
        },\
        {\
          text:"数据包：",color:"#b1f7f2",extra:[{text:"Zaycun\n\n",color:"#e0e0e0",hover_event:{action:show_text,value:"UUID: d6c989c3-b6d9-4644-b42d-5b3f83f07ee2"}}]\
        },\
        {\
          text:"地图版本：",color:"#b1f7f2",extra:[{text:"$(Version)\n",color:"#e0e0e0"}]\
        },\
        {\
          text:"支持的游戏版本：",color:"#b1f7f2",extra:[{text:"26.2\n\n",color:"#e0e0e0"}]\
        },\
        {\
          text:"关卡总数：",color:"#b1f7f2",extra:[{text:"7关（0~6）\n",color:"#e0e0e0"}]\
        },\
        {\
          text:"游玩人数限制：",color:"#b1f7f2",extra:[{text:"1人\n",color:"#e0e0e0"}]\
        },\
        {\
          text:"地图类型：",color:"#b1f7f2",extra:[{text:"解谜/密室逃脱\n\n",color:"#e0e0e0"}]\
        },\
        {\
          text:"感谢以下参与测试的玩家：\n",color:"#b1f7f2",extra:[{text:"Emittttir",color:"#e0e0e0",hover_event:{action:show_text,value:"UUID: c26430ce-6968-4f0a-8cae-20598e35d53a"}},{text:"、",color:"#cecaca"},{text:"xianzhe04",color:"#e0e0e0",hover_event:{action:show_text,value:"UUID: 15a8d422-e290-4e77-ba90-f76cdd14b222"}},{text:"、",color:"#cecaca"},{text:"shwiq",color:"#e0e0e0",hover_event:{action:show_text,value:"UUID: 49dce1e7-290f-4720-83bc-3f90a7a3dd76"}}]\
        },\
        {\
          text:"\n\n\n点击此处查看解答",\
          color:"#e0e0e0",\
          bold:true,\
          click_event:{\
            action:open_url,\
            url:'https://www.bilibili.com/video/BV1o9N76oELS/'\
          }\
        }\
      ]\
    }\
  }