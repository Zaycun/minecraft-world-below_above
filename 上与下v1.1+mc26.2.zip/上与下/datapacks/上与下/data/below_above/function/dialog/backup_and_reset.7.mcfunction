$dialog show @s \
  {\
    type:"minecraft:multi_action",\
    pause:false,\
    title:[{"text":"备","color":"#01fff2"},{"text":"份与","color":"white"},{"text":"重","color":"#fa6267"},{"text":"置","color":"white"}],\
    body:{\
      type:"plain_message",\
      contents:{\
        text:""\
      }\
    },\
    actions:[\
      {\
        label: "$(backup1_text)",\
        width: 100,\
        tooltip: {text: "进行备份"},\
        action: {\
          type: "run_command",\
          command: "trigger config.trigger set 7"\
         }\
       },\
       {\
        label: [{text:"读取备份1"},{text:" $(rollback1_text)",color:"#fb6f6f"}],\
        width: 100,\
        tooltip: {text: "进行回档"},\
        action: {\
          type: "run_command",\
          command: "trigger config.trigger set 8"\
         }\
       },\
       {\
        label: "$(backup2_text)",\
        width: 100,\
        tooltip: {text: "进行备份"},\
        action: {\
          type: "run_command",\
          command: "trigger config.trigger set 9"\
         }\
       },\
       {\
        label: [{text:"读取备份2"},{text:" $(rollback2_text)",color:"#f2fb6f"}],\
        width: 100,\
        tooltip: {text: "进行回档"},\
        action: {\
          type: "run_command",\
          command: "trigger config.trigger set 10"\
         }\
       },\
       {\
        label: "$(backup3_text)",\
        width: 100,\
        tooltip: {text: "进行备份"},\
        action: {\
          type: "run_command",\
          command: "trigger config.trigger set 11"\
         }\
       },\
       {\
        label: [{text:"读取备份3"},{text:" $(rollback3_text)",color:"#6fb3fb"}],\
        width: 100,\
        tooltip: {text: "进行回档"},\
        action: {\
          type: "run_command",\
          command: "trigger config.trigger set 12"\
         }\
       },\
       {\
        label: {text: "重置本关"},\
        width: 200,\
        tooltip: {text: "重置到本关开始！",color:"#fa6267"},\
        action: {\
          type: "run_command",\
          command: "trigger config.trigger set 13"\
        }\
      }\
    ],\
    exit_action:{\
      label: "返回",\
      action:{\
        type: "show_dialog",\
        dialog: "below_above:config"\
       }\
    }\
  }