function below_above:backup_check_area
#范围检查

function below_above:backup_check_spectator
#旁观者物品检查

execute if predicate {condition:"entity_properties",entity:"this",predicate:{movement:{speed:0.0}}} run scoreboard players add #backup_check dummy 1
execute unless predicate {condition:"entity_properties",entity:"this",predicate:{movement:{speed:0.0}}} run tellraw @s {"text":"请停止移动后再尝试备份！","color":"red"}
#移动检查

execute if predicate {condition:"entity_properties",entity:"this",predicate:{flags:{is_on_ground:true}}} run scoreboard players add #backup_check dummy 1
execute unless predicate {condition:"entity_properties",entity:"this",predicate:{flags:{is_on_ground:true}}} run tellraw @s {"text":"请在平地上后再尝试备份！","color":"red"}
#落地检查

execute store result score #backup_check_Air dummy run data get entity @s Air
execute if score #backup_check_Air dummy matches 300 run scoreboard players add #backup_check dummy 1
execute unless score #backup_check_Air dummy matches 300 run tellraw @s {"text":"请在非窒息环境下再尝试备份！","color":"red"}
#窒息检查

execute store result score #backup_check_Fire dummy run data get entity @s Fire
execute if score #backup_check_Fire dummy matches ..510 run scoreboard players add #backup_check dummy 1
execute if score #backup_check_Fire dummy matches 511.. run tellraw @s {"text":"请等待着火停止后再尝试备份！","color":"red"}
#着火时长检查

execute unless data entity @s TicksFrozen run scoreboard players add #backup_check dummy 1
execute if data entity @s TicksFrozen run tellraw @s {"text":"请处于非冷冻状态后再尝试备份！","color":"red"}
#冷冻检查

execute unless data entity @s ender_pearls run scoreboard players add #backup_check dummy 1
execute if data entity @s ender_pearls run tellraw @s {"text":"请等待末影珍珠落地后再尝试备份！","color":"red"}
#珍珠落地检查

execute unless data entity @s ShoulderEntityLeft run scoreboard players add #backup_check dummy 1
execute if data entity @s ShoulderEntityLeft run tellraw @s {"text":"请让鹦鹉离开你的左肩后再尝试备份！","color":"red"}
#左肩实体检查

execute unless data entity @s ShoulderEntityRight run scoreboard players add #backup_check dummy 1
execute if data entity @s ShoulderEntityRight run tellraw @s {"text":"请让鹦鹉离开你的右肩后再尝试备份！","color":"red"}
#右肩实体检查

execute store result score #backup_check_HurtTime dummy run data get entity @s HurtTime
execute if score #backup_check_HurtTime dummy matches ..0 run scoreboard players add #backup_check dummy 1
execute unless score #backup_check_HurtTime dummy matches ..0 run tellraw @s {"text":"请停止受伤后再尝试备份！","color":"red"}
#未受伤检查