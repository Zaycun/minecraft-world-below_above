damage @a[x=-23,y=-32,z=-23,dx=46,dy=1,dz=46,limit=1] 2048 minecraft:out_of_world
execute if score level dummy matches 6 run schedule function below_above:level_detection/level6 1t