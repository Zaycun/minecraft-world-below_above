data modify storage below_above:backup_reset advancements_end_id set value none
$data modify storage below_above:backup_reset advancements_end_id set from storage below_above:present_advancements end[$(advancements_count)]
function below_above:backup_reset/advancements/end.3 with storage below_above:backup_reset
#获取当前计数现在进度id