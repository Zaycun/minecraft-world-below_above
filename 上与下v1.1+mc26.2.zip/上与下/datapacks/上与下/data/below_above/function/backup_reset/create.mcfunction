function below_above:backup_reset/recipe_book
function below_above:backup_reset/advancements/adventure.1
function below_above:backup_reset/advancements/end.1
function below_above:backup_reset/advancements/husbandry.1
function below_above:backup_reset/advancements/nether.1
function below_above:backup_reset/advancements/story.1