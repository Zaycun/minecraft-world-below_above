data modify storage below_above:backup_reset advancements_nether_id set value none
$data modify storage below_above:backup_reset advancements_nether_id set from storage below_above:present_advancements nether[$(advancements_count)]
function below_above:backup_reset/advancements/nether.3 with storage below_above:backup_reset
#获取当前计数现在进度id