clear @s
advancement revoke @s everything
advancement grant @s only below_above:first_join
tag @s remove player
recipe take @a *
effect clear @s
effect give @s minecraft:night_vision infinite 255 true
experience add @s -2147483647 points
attribute @s minecraft:waypoint_receive_range base reset
function below_above:join_detection/set_spectator_spawnpoint
gamemode spectator @s
teleport @s @a[tag=player,limit=1]
tellraw @s {text:"一名玩家正在游戏中，你现已加入旁观者。",color:"red"}