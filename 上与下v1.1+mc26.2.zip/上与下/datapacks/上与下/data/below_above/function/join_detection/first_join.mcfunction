execute if entity @s[tag=!player] if score is_starting dummy matches 1 run function below_above:join_detection/become_spectator
execute if entity @s[tag=!player] if score is_starting dummy matches 0 run function below_above:join_detection/become_waiter
