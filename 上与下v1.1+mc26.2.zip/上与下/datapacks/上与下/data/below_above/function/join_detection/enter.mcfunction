tag @s add just_entered
scoreboard players reset @s enter_detection

execute if entity @s[tag=!player] if score is_starting dummy matches 0 run function below_above:join_detection/become_waiter
execute if entity @s[tag=!player] if score is_starting dummy matches 1 run function below_above:join_detection/become_spectator

execute if entity @s[tag=player] if score is_starting dummy matches 1 if entity @a[tag=player,tag=!just_entered] run function below_above:join_detection/player_become_spectator
execute if entity @s[tag=player] if score is_starting dummy matches 1 unless entity @a[tag=player,tag=!just_entered] run gamemode survival @s
execute if entity @s[tag=player] if score is_starting dummy matches 0 run function below_above:join_detection/player_become_waiter
tag @s remove just_entered