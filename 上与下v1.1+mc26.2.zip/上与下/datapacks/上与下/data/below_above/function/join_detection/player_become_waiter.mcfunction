
clear @s

advancement revoke @s everything
advancement grant @s only below_above:first_join

tag @s remove player
recipe take @a *
effect clear @s
effect give @s minecraft:saturation infinite 255 true
effect give @s minecraft:weakness infinite 255 true
experience add @s -2147483647 points
attribute @s minecraft:waypoint_receive_range base reset
spawnpoint @s -73 1 23 180 0
gamemode adventure @s
teleport @s -73 1 23 180 0
