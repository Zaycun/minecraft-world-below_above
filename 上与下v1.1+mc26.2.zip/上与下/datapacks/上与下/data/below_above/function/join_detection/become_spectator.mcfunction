clear @s
tag @s remove player
effect clear @s
effect give @s minecraft:night_vision infinite 255 true
effect give @s minecraft:saturation infinite 255 true
experience add @s -2147483647 points
attribute @s minecraft:waypoint_receive_range base reset
function below_above:join_detection/set_spectator_spawnpoint
gamemode spectator @s
teleport @s @a[tag=player,limit=1]
tellraw @s {text:"游戏已开始，你已加入旁观者。",color:"red"}