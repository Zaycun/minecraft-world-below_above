execute unless score level dummy matches 1..7 run return run spawnpoint @s -73 1 23 180 0
execute if score level dummy matches 1 run return run spawnpoint @s -124 -12 55 270 0
execute if score level dummy matches 2 run return run spawnpoint @s -131 -48 7 90 0
execute if score level dummy matches 3 run return run spawnpoint @s -73 82 -57 0 0
execute if score level dummy matches 4 run return run spawnpoint @s -14 6 68 0 0
execute if score level dummy matches 5 run return run spawnpoint @s -86 -6 90 0 0
execute if score level dummy matches 6 run return run spawnpoint @s 0 46 0 90 0
execute if score level dummy matches 7 run return run spawnpoint @s 0 1 0 0 0