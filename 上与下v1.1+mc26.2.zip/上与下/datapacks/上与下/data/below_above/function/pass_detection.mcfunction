execute as @e[type=player,tag=player,limit=1] if score level dummy matches 0 run return \
  run execute if predicate below_above:cross_check run function below_above:cross_level/0_to_1.1

execute as @e[type=player,tag=player,limit=1] if score level dummy matches 1 run return \
  run execute if predicate below_above:cross_check run function below_above:cross_level/1_to_2.1

execute as @e[type=player,tag=player,limit=1] if score level dummy matches 2 run return \
  run execute if predicate below_above:cross_check run function below_above:cross_level/2_to_3.1

execute as @e[type=player,tag=player,limit=1] if score level dummy matches 3 run return \
  run execute if predicate below_above:cross_check run function below_above:cross_level/3_to_4.1

execute as @e[type=player,tag=player,limit=1] if score level dummy matches 4 run return \
  run execute if predicate below_above:cross_check run function below_above:cross_level/4_to_5.1

execute as @e[type=player,tag=player,limit=1] if score level dummy matches 5 run return \
  run execute if predicate below_above:cross_check run function below_above:cross_level/5_to_6.1

execute as @e[type=player,tag=player,limit=1] if score level dummy matches 6 run return \
  run execute if predicate below_above:cross_check run function below_above:cross_level/win