execute if entity @s[tag=!player] run return run function below_above:recover_spectator_effects

execute if predicate {condition:entity_properties,entity:this,predicate:{effects:{night_vision:{amplifier:255,visible:false}}}} run effect clear @s[tag=player] night_vision
execute if predicate {condition:entity_properties,entity:this,predicate:{effects:{haste:{amplifier:3,visible:false}}}} run effect clear @s[tag=player] haste

execute if score #setting_night_vision dummy matches 1 run effect give @s[tag=player] night_vision infinite 255 true
execute if score #setting_faster_mining dummy matches 1 run effect give @s[tag=player] haste infinite 3 true

effect give @s[tag=player] saturation infinite 255 true
advancement revoke @s only below_above:effects_changed