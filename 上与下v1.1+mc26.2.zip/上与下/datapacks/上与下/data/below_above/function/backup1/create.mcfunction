scoreboard players set #is_loading dummy 1
scoreboard players set #has_backup1 dummy 1
scoreboard players add #level_backup_times dummy 1
scoreboard players add #total_backup_times dummy 1

data modify storage below_above:backup1 clock_hour set string block -75 305 17 LastOutput.text 1 3
data modify storage below_above:backup1 clock_minute set string block -75 305 17 LastOutput.text 4 6
data modify storage below_above:backup1 clock_second set string block -75 305 17 LastOutput.text 7 9

function below_above:backup1/player
function below_above:backup1/container
function below_above:backup1/advancements/adventure.1
function below_above:backup1/advancements/end.1
function below_above:backup1/advancements/husbandry.1
function below_above:backup1/advancements/nether.1
function below_above:backup1/advancements/story.1

execute if score level dummy matches 0 run function below_above:backup1/structure/level0.1
execute if score level dummy matches 1 run function below_above:backup1/structure/level1.1
execute if score level dummy matches 2 run function below_above:backup1/structure/level2.1
execute if score level dummy matches 3 run function below_above:backup1/structure/level3.1
execute if score level dummy matches 4 run function below_above:backup1/structure/level4.1
execute if score level dummy matches 5 run function below_above:backup1/structure/level5.1
execute if score level dummy matches 6 run function below_above:backup1/structure/level6.1
