execute as @e[x=-144,y=-49,z=0,dx=15,dy=92,dz=15,type=!minecraft:player] run function below_above:backup_entity_data

execute in minecraft:overworld run setblock -144 -6 14 minecraft:redstone_block
execute in minecraft:overworld run setblock -144 41 14 minecraft:redstone_block
execute in below_above:backup1_structure run forceload add -144 0 -129 15

schedule function below_above:backup1/structure/level2.2 4t append
#必须是4t