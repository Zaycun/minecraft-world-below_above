execute store result score #backup1_Health dummy run data get entity @s Health 100000000
execute store result score #backup1_AbsorptionAmount dummy run data get entity @s AbsorptionAmount 100000000
execute store result score #backup1_Fire dummy run data get entity @s Fire
data modify storage below_above:backup1 Dimension set from entity @s Dimension
data modify storage below_above:backup1 Pos set from entity @s Pos
data modify storage below_above:backup1 Rotation set from entity @s Rotation
data remove storage below_above:backup1 active_effects
data modify storage below_above:backup1 active_effects set from entity @s active_effects
data modify storage below_above:backup1 XpTotal set from entity @s XpTotal
data modify storage below_above:backup1 respawn set from entity @s respawn
data modify storage below_above:backup1 recipeBook set from entity @s recipeBook.recipes
#玩家数据备份

scoreboard players set #backup1_pose dummy 0

execute at @s anchored eyes positioned ^ ^ ^ summon minecraft:marker if entity @p[distance=..1.28,tag=player] unless entity @p[distance=..0.41,tag=player] run scoreboard players set #backup1_pose dummy 1
#潜行

execute at @s anchored eyes positioned ^ ^ ^ run \
  execute as @n[type=minecraft:marker] if entity @p[distance=..0.41,tag=player] run scoreboard players set #backup1_pose dummy 2
#爬行
execute at @s anchored eyes positioned ^ ^ ^ run kill @n[type=minecraft:marker]