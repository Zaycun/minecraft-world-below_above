execute in minecraft:overworld run setblock -91 45 -39 minecraft:bedrock
execute in minecraft:overworld run setblock -91 95 -39 minecraft:bedrock

execute in below_above:backup1_structure run teleport @e[x=-96,y=0,z=-80,dx=47,dy=97,dz=47,type=!minecraft:player] -73 -128 -57
execute in below_above:backup1_structure run kill @e[x=-72.5,y=-128,z=-56.5,distance=..1]
execute in below_above:backup1_structure run place template below_above:backup1_galaxy.1 -96 0 -80 none none 1 0 strict
execute in below_above:backup1_structure run place template below_above:backup1_galaxy.2 -96 48 -80 none none 1 0 strict
execute in below_above:backup1_structure run setblock -91 45 -39 minecraft:bedrock
execute in below_above:backup1_structure run setblock -91 95 -39 minecraft:bedrock
execute in below_above:backup1_structure run forceload remove -96 -80 -49 -33

schedule function below_above:backup1/finish.1 5t