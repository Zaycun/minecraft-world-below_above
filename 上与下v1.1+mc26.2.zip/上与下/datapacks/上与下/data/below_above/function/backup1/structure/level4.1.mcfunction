execute in minecraft:overworld run setblock -24 4 73 minecraft:redstone_block
execute in below_above:backup1_structure run forceload add -32 48 -1 79

schedule function below_above:backup1/structure/level4.2 4t append
#必须是4t