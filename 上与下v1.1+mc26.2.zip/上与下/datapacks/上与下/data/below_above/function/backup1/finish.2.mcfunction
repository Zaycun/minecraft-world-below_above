scoreboard players set #is_loading dummy 0
$tellraw @s [{text:"[$(clock_hour):$(clock_minute):$(clock_second)]",color:"#fb6f6f"},{text:" 备份1创建完成！",color:"#ec93dc"}]