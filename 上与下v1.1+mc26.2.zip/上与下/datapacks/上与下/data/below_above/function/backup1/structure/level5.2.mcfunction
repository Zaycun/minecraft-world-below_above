execute in minecraft:overworld run setblock -89 0 105 minecraft:grass_block

execute in below_above:backup1_structure run teleport @e[x=-89,y=-9,z=87,dx=19,dy=11,dz=19,type=!minecraft:player] -86 -128 90
execute in below_above:backup1_structure run kill @e[x=-85.5,y=-128,z=90.5,distance=..1]
execute in below_above:backup1_structure run place template below_above:backup1_subtle -89 -9 87 none none 1 0 strict
execute in below_above:backup1_structure run setblock -89 0 105 minecraft:grass_block
execute in below_above:backup1_structure run forceload remove -96 80 -65 111

schedule function below_above:backup1/finish.1 5t