data remove storage below_above:backup1_advancements adventure

execute store result score #backup_advancements_number dummy run data get storage below_above:present_advancements adventure
execute if score #backup_advancements_number dummy matches ..0 run return fail
scoreboard players remove #backup_advancements_number dummy 1
#adventure现在进度数量存入记分板

data modify storage below_above:backup1 advancements_count set value 0
scoreboard players set #backup_advancements_count dummy 0

function below_above:backup1/advancements/adventure.2 with storage below_above:backup1
#计数设为0

