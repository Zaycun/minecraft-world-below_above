effect give @s minecraft:night_vision infinite 255 true
effect give @s minecraft:saturation infinite 255 true
advancement revoke @s only below_above:effects_changed