execute unless data storage below_above:global Version run function below_above:load_once


scoreboard players set #is_loading dummy 1

execute if score #has_backup1 dummy matches 1 run return run schedule function below_above:re_backup_structure/allocation 8t
execute if score #has_backup2 dummy matches 1 run return run schedule function below_above:re_backup_structure/allocation 8t
execute if score #has_backup3 dummy matches 1 run return run schedule function below_above:re_backup_structure/allocation 8t

scoreboard players set #is_loading dummy 0