gamemode survival @s
execute in minecraft:overworld run teleport @a -124.0 -12 55 270 0
stopwatch restart below_above:level_time_taken
execute as @a at @s run playsound minecraft:entity.experience_orb.pickup ui @s ~ ~ ~ 1.0 0.890899
playsound minecraft:entity.experience_orb.pickup ui @s -124.0 -12 55 1.0 0.890899
scoreboard players set level dummy 1