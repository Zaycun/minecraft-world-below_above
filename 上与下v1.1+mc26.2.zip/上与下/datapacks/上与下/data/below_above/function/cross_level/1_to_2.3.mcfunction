gamemode survival @s
execute in minecraft:overworld run teleport @a -131 -48 7 90 0
stopwatch restart below_above:level_time_taken
execute as @a at @s run playsound minecraft:entity.experience_orb.pickup ui @a ~ ~ ~ 1.0 0.943874
playsound minecraft:entity.experience_orb.pickup ui @s -131 -48 7 1.0 0.943874
scoreboard players set level dummy 2