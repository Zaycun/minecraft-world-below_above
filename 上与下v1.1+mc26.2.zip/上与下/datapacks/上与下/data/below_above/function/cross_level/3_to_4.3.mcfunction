gamemode survival @s
execute in minecraft:overworld run teleport @a -14 6 68 0 0
stopwatch restart below_above:level_time_taken
execute as @a at @s run playsound minecraft:entity.experience_orb.pickup ui @a ~ ~ ~ 1.0 1.059463
playsound minecraft:entity.experience_orb.pickup ui @s -14 6 68 1.0 1.059463
scoreboard players set level dummy 4