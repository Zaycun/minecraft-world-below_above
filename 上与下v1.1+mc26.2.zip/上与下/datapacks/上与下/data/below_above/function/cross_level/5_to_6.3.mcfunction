gamemode survival @s
execute in minecraft:overworld run teleport @a 0 55 0 0 0
stopwatch restart below_above:level_time_taken
execute as @a at @s run playsound minecraft:entity.experience_orb.pickup ui @a ~ ~ ~ 1.0 1.189207
playsound minecraft:entity.experience_orb.pickup ui @s 0 55 0 1.0 1.189207
scoreboard players set level dummy 6
function below_above:level_detection/level6