execute if score level dummy matches 1.. run return fail
scoreboard players set level dummy -1

function below_above:backup_reset/create
#创建重置备份

clear @a
effect clear @a
effect give @a[tag=!player] minecraft:night_vision infinite 255 true
effect give @a[tag=!player] minecraft:saturation infinite 255 true
gamemode spectator @a
effect give @a minecraft:instant_health 10 252 true
effect give @a minecraft:resistance 1 4 true
experience add @a -2147483647 points
spawnpoint @a -124 -12 55 270 0
setworldspawn -124 -12 55 270 0
time set 30000t

scoreboard players set #has_backup1 dummy 0
scoreboard players set #has_backup2 dummy 0
scoreboard players set #has_backup3 dummy 0


title @a title {text:"关卡1",color:"#b1f7f2"}
title @a subtitle {text:"MINE和CRAFT"}


execute store result storage below_above:statistics level0_backup_times int 1 run scoreboard players get #level_backup_times dummy
execute store result storage below_above:statistics level0_rollback_times int 1 run scoreboard players get #level_rollback_times dummy

scoreboard players reset #level_backup_times dummy
scoreboard players reset #level_rollback_times dummy

execute store result score #level_time_taken dummy run stopwatch query below_above:level_time_taken 1000
scoreboard players operation #level_time_taken_h dummy = #level_time_taken dummy
scoreboard players operation #level_time_taken_ms dummy = #level_time_taken_h dummy
scoreboard players operation #level_time_taken_h dummy /= 3600000 dummy
scoreboard players operation #level_time_taken_ms dummy %= 3600000 dummy
scoreboard players operation #level_time_taken_m dummy = #level_time_taken_ms dummy
scoreboard players operation #level_time_taken_m dummy /= 60000 dummy
scoreboard players operation #level_time_taken_ms dummy %= 60000 dummy
scoreboard players operation #level_time_taken_s dummy = #level_time_taken_ms dummy
scoreboard players operation #level_time_taken_s dummy /= 1000 dummy
scoreboard players operation #level_time_taken_ms dummy %= 1000 dummy


execute store result storage below_above:statistics level0_time_taken_h int 1 run scoreboard players get #level_time_taken_h dummy
execute store result storage below_above:statistics level0_time_taken_m int 1 run scoreboard players get #level_time_taken_m dummy
execute store result storage below_above:statistics level0_time_taken_s int 1 run scoreboard players get #level_time_taken_s dummy
execute store result storage below_above:statistics level0_time_taken_ms int 1 run scoreboard players get #level_time_taken_ms dummy

execute if score #level_time_taken_ms dummy matches 0..9 run data modify storage below_above:statistics level0_time_taken_placeholder set value "00"
execute if score #level_time_taken_ms dummy matches 10..99 run data modify storage below_above:statistics level0_time_taken_placeholder set value "0"
execute if score #level_time_taken_ms dummy matches 100..999 run data modify storage below_above:statistics level0_time_taken_placeholder set value ""


#存储计时
tellraw @a \
  [\
    {\
      text:"过关！",color:"#b1f7f2",bold:true,\
    },\
    {\
      text:"关卡0用时：",color:"#e0e0e0",bold:false,\
    },\
    {\
      score:{name:"#level_time_taken_h",objective:dummy},color:"white",bold:false,extra:[{text:"h",color:"#cecaca"}]\
    },\
    {\
      score:{name:"#level_time_taken_m",objective:dummy},color:"white",bold:false,extra:[{text:"m",color:"#cecaca"}]\
    },\
    {\
      score:{name:"#level_time_taken_s",objective:dummy},color:"white",bold:false,extra:[{text:"s",color:"#cecaca"}]\
    }\
  ]


schedule function below_above:cross_level/0_to_1.2 2t append